/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator.crawler;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * A DNF representation for string matching.
 * 
 * @author Michael Wurst
 * @version $Id: StringMatchingRuleSet.java,v 1.1 2007/05/27 21:45:37 ingomierswa Exp $
 *
 */
public class StringMatchingRuleSet {

    private final List<List<StringMatchingLiteral>> dnfBasedRules = new LinkedList<List<StringMatchingLiteral>>();
    
    /**
     * A a new conjuctive element to the DNF.
     * 
     * @param conj the conjuction
     */
    public void addConjunction(List<StringMatchingLiteral> conj) {
        dnfBasedRules.add(conj);
    }
    
    /**
     * Check the DNF against a given string
     * 
     * @param s the string
     * @return true, if the DNF is fullfilled, or if it is empty
     */
    public boolean check(String s) {
    
        // If the rule set is empty, assume that it is fulfilled for all strings
        if(dnfBasedRules.size() == 0)
            return true;
        
        boolean result = false;
        
        for(Iterator<List<StringMatchingLiteral>> it = dnfBasedRules.iterator(); it.hasNext()&&(!result);) {
            
            List<StringMatchingLiteral> conj = it.next();
            boolean conjResult = true;
            for(Iterator<StringMatchingLiteral> it2 = conj.iterator(); it2.hasNext()&&(conjResult);) {
                if(!it2.next().check(s))
                    conjResult = false;
            }
            
            result = conjResult;
        }
            
        return result;
    }
    
}
