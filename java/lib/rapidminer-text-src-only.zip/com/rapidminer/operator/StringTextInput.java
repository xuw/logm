/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.rapidminer.example.Attribute;
import com.rapidminer.example.Example;
import com.rapidminer.example.ExampleSet;
import com.rapidminer.example.Tools;
import com.rapidminer.example.table.AttributeFactory;
import com.rapidminer.parameter.ParameterType;
import com.rapidminer.parameter.ParameterTypeBoolean;
import com.rapidminer.tools.Ontology;

import edu.udo.cs.wvtool.config.WVTConfiguration;
import edu.udo.cs.wvtool.config.WVTConfigurationFact;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.main.WVTFileInputList;
import edu.udo.cs.wvtool.main.WVTInputList;

/**
 * This operator takes an input example set and uses the values of the string attributes as texts. String attributes are attributes with value type &quot;string&quot;. The result is a set of attributes representing word occurrence information from the text contained in the strings. The set of words (attributes) is determined from the given data set. The parameters and possible sub-operators as well as restrictions are the same as for the WVTool2Operator.
 * 
 * This operator is especially usefull if you already have text data represented in a single example set file, e.g. an Arff file containing string attributes or other example sets defining such string attributes. If you want to read text data directly from files we recommend the WVToolOperator of the Word Vector Tool plugin.
 * 
 * @author Ingo Mierswa, Michael Wurst
 * @version $Id: StringTextInput.java,v 1.1 2007/07/27 22:46:06 ingomierswa Exp $
 */
public class StringTextInput extends TextInput {

    private Attribute label = null;

    /** Creates a new operator instance. */
    public StringTextInput(OperatorDescription description) {
        super(description);
    }

    public Class[] getInputClasses() {
        return new Class[] { ExampleSet.class };
    }

    protected Attribute getLabel() throws OperatorException {
        return label;
    }

    protected WVTInputList createInputList() throws OperatorException {
        ExampleSet exampleSet = getInput(ExampleSet.class);
        label = exampleSet.getAttributes().getLabel();

        // if nominal attributes should also be filtered their value type must be set to 'string'
        if (getParameterAsBoolean("filter_nominal_attributes")) {
            for (Attribute attribute : exampleSet.getAttributes()) {
                if (attribute.isNominal()) {
                    AttributeFactory.changeValueType(attribute, Ontology.STRING);
                }
            }
        }

        // create input list
        return createInputList(exampleSet);
    }

    protected WVTConfiguration createConfiguration() throws OperatorException {
        WVTConfiguration config = new WVTConfiguration();
        log("Creating WVTool configuration including source as text loader...");
        config.setConfigurationRule(WVTConfiguration.STEP_LOADER, new WVTConfigurationFact(
                "edu.udo.cs.wvtool.generic.loader.SourceAsTextLoader"));
        return config;
    }

    private WVTInputList createInputList(ExampleSet exampleSet) throws OperatorException {
        log("Creating WVTool input list from input string attributes.");

        if (!Tools.containsValueType(exampleSet, Ontology.STRING)) {
            throw new UserError(this, 128, Ontology.VALUE_TYPE_NAMES[Ontology.STRING]);
        }

        Attribute documentClassAtt = exampleSet.getAttributes().getLabel();
        if ((documentClassAtt != null) && !documentClassAtt.isNominal())
            throw new UserError(this, 101, new Object[] { "wvtool", documentClassAtt });

        Attribute contentTypeAtt = exampleSet.getAttributes().get("type");
        Attribute contentEncodingAtt = exampleSet.getAttributes().get("encoding");
        Attribute contentLanguageAtt = exampleSet.getAttributes().get("language");

        String defaultContentType = getParameterAsString("default_content_type");
        String defaultContentEncoding = getParameterAsString("default_content_encoding");
        String defaultContentLanguage = getParameterAsString("default_content_language");

        WVTFileInputList list = null;
        if (documentClassAtt != null) {
            list = new WVTFileInputList(documentClassAtt.getMapping().size());
        } else {
            list = new WVTFileInputList(0);
        }

        for (Example e : exampleSet) {
            String contentType = (contentTypeAtt != null) ? e.getValueAsString(contentTypeAtt) : defaultContentType;
            String contentEncoding = (contentEncodingAtt != null) ? e.getValueAsString(contentEncodingAtt)
                    : defaultContentEncoding;
            String contentLanguage = (contentLanguageAtt != null) ? e.getValueAsString(contentLanguageAtt)
                    : defaultContentLanguage;
            StringBuffer textBuffer = new StringBuffer();
            for (Attribute attribute : exampleSet.getAttributes()) {
                if (Ontology.ATTRIBUTE_VALUE_TYPE.isA(attribute.getValueType(), Ontology.STRING)) {
                    textBuffer.append(e.getValueAsString(attribute) + " ");
                }
            }
            String text = textBuffer.toString();

            if (documentClassAtt != null) {
                int labelValue = (int)e.getValue(documentClassAtt);
                list.addEntry(new WVTDocumentInfo(text, contentType, contentEncoding, contentLanguage, labelValue));
            } else {
                list.addEntry(new WVTDocumentInfo(text, contentType, contentEncoding, contentLanguage));
            }
        }

        return list;
    }

    public List<ParameterType> getParameterTypes() {
        List<ParameterType> types = new LinkedList<ParameterType>();
        
        types.add(new ParameterTypeBoolean("filter_nominal_attributes",
                "Indicates if nominal attributes should also be filtered in addition to string attributes.", false));

        types.addAll(super.getParameterTypes());
        
        Iterator i = types.iterator();
        while (i.hasNext()) {
            ParameterType type = (ParameterType) i.next();
            if (type.getKey().equals(WVTConfiguration.STEP_LOADER)) {
                i.remove();
                break;
            }
        }
        return types;
    }
}
