package com.rapidminer.operator.tokenizer;

import java.util.List;

import com.rapidminer.operator.AbstractTokenProcessor;
import com.rapidminer.operator.IOObject;
import com.rapidminer.operator.OperatorDescription;
import com.rapidminer.operator.OperatorException;
import com.rapidminer.parameter.ParameterType;
import com.rapidminer.parameter.ParameterTypeInt;

import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.util.TokenEnumeration;
import edu.udo.cs.wvtool.util.WVToolException;

/**
 * Creates ngrams of the input terms. If an input term is shorter than the specified length of 
 * output ngrams it is directly passed to the output token stream.
 * 
 * @author Michael Wurst
 * @version $Id$
 *
 */
public class NGramTokenizer extends AbstractTokenProcessor {

    edu.udo.cs.wvtool.generic.tokenizer.NGramTokenizer tokenizer = null;
    
    public NGramTokenizer(OperatorDescription description) {
        super(description);
    }

    public IOObject[] apply() throws OperatorException {
        
        tokenizer = new edu.udo.cs.wvtool.generic.tokenizer.NGramTokenizer(getParameterAsInt("k"));
        
        return super.apply();
    }
     
    protected TokenEnumeration process(TokenEnumeration tokens, WVTDocumentInfo docInfo) throws WVToolException {
        return tokenizer.tokenize(tokens, docInfo);
    }

    public List<ParameterType> getParameterTypes() {

        List<ParameterType> types = super.getParameterTypes();

        types.add(new ParameterTypeInt("k", "The maximal length of the ngrams.", 1, (int) Double.POSITIVE_INFINITY, 3));
        return types;
    }
    
}
