package com.rapidminer.operator;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.util.LinkedList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import com.rapidminer.gui.tools.ExtendedJScrollPane;
import com.rapidminer.gui.tools.SwingTools;
import com.rapidminer.tools.Tools;

import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.main.WVTTokenSequence;
import edu.udo.cs.wvtool.util.TokenEnumeration;
import edu.udo.cs.wvtool.util.WVToolException;

/**
 * A sequence of tokens combines with a document info.
 * 
 * @author Michael Wurst, Ingo Mierswa
 * @version $Id$
 *
 */
public class TokenSequence extends ResultObjectAdapter implements WVTTokenSequence {

    private static final long serialVersionUID = -1513798588906738472L;

    private List<String> tokens = new LinkedList<String>();

    private WVTDocumentInfo docInfo;

    /**
     * Create a new token sequence containing a single token.
     * 
     * @param s the token
     * @param docInfo the corresponding document info
     */
    public TokenSequence(String s, WVTDocumentInfo docInfo) {
        tokens.add(s);
        this.docInfo = docInfo;
    }

    /**
     * Create a new token sequence from a token enumeration.
     * 
     * @param tokenEnum the token enumeration
     * @param docInfo the corresponding document info
     */
    public TokenSequence(TokenEnumeration tokenEnum, WVTDocumentInfo docInfo) throws WVToolException {
        while(tokenEnum.hasMoreTokens())
            addToken(tokenEnum.nextToken());
        this.docInfo = docInfo;
    }
    
    /**
     * Add a token to the end of the sequencr
     * 
     * @param s the token
     */
    public void addToken(String s) {
        tokens.add(s);
    }
    
    public List getTokenSequence() {
        return tokens;
    }

    public WVTDocumentInfo getDocumentInfo() {
        return docInfo;
    }

    public String getExtension() {
        return ".txt";
    }

    public String getFileDescription() {
        return "";
    }

    public Component getVisualizationComponent(IOContainer container) {
    	JPanel result = new JPanel(new BorderLayout());
    	result.setBorder(BorderFactory.createEmptyBorder(11,11,11,11));
    	
    	// doc info
    	JLabel label = new JLabel("Document: " + docInfo.getSourceName());
    	label.setBorder(BorderFactory.createEmptyBorder(0,0,7,0));
    	result.add(label, BorderLayout.NORTH);
    	
    	// tokens
    	JTextPane textArea = new JTextPane();
    	textArea.setEditable(false);
    	
        SimpleAttributeSet attributeSet = new SimpleAttributeSet();
    	Document doc = textArea.getStyledDocument();
    	boolean flag = true;
    	for (String s : tokens) {
    		if (flag) {
    	        StyleConstants.setForeground(attributeSet, new Color(255, 51, 204));    			
    		} else {
    	        StyleConstants.setForeground(attributeSet, new Color(51, 51, 255));
    		}
    		flag = !flag;
    		try {
    			doc.insertString(doc.getLength(), s + " ", attributeSet);
    		} catch (BadLocationException e) {
    			SwingTools.showSimpleErrorMessage("Error during logging: ", e);
    		}
    	}
        textArea.setCaretPosition(0);
    	
    	result.add(new ExtendedJScrollPane(textArea), BorderLayout.CENTER);
    	
    	return result;
    }
    
    public String toString() {
        StringBuffer buf = new StringBuffer();
        buf.append(docInfo.getSourceName());
        buf.append(Tools.getLineSeparator());
        buf.append("number of tokens: " + tokens.size());
        return buf.toString();
    }
}
