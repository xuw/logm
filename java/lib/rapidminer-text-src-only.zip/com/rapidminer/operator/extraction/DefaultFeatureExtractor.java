/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator.extraction;

import java.util.Collection;
import java.util.Iterator;

import com.rapidminer.example.Attribute;
import com.rapidminer.example.table.DataRow;
import com.rapidminer.operator.extraction.util.NumberParser;

import edu.udo.cs.wvtool.config.WVTConfiguration;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;

/**
 * Enables feature extraction based on a set of variables and patterns provided by the user.
 * 
 * @author Michael Wurst, Ingo Mierswa
 * @version $Id: DefaultFeatureExtractor.java,v 1.1 2007/05/27 21:45:35 ingomierswa Exp $
 *
 */
public class DefaultFeatureExtractor implements FeatureExtractor {

	private final AttributeQueryMap aqMap;

    private final WVTConfiguration config;
    
    
    /**
     * Initialize
     * 
     * @param aqMap
     * @param config
     */
	public DefaultFeatureExtractor(AttributeQueryMap aqMap, WVTConfiguration config) {
		this.aqMap = aqMap;
        this.config = config;
	}

    /**
     * Extract value and write them to a data row.
     * @param info the document info
     * @param dr the data row, which must be sufficiently large
     * 
     */
	public void extract(WVTDocumentInfo info, DataRow dr) throws ExtractionException {
		
        TextExtractionWrapper wrapper = new TextExtractionWrapper(info, config);
        
	    // For each attribute, apply the extractor
        
		for (Attribute att : aqMap.getAttributes()) {
			TextExtractor query = aqMap.getQuery(att);
            String val = extractValue(wrapper, query, info);
            
            if(val != null) {
				if (!att.isNominal()) {

					double numericalValue = Double.NaN;

					try {
						numericalValue = NumberParser.parse(val);
					} catch (NumberFormatException e1) {
						numericalValue = Double.NaN;
					}
					dr.set(att, numericalValue);
				} else {
					dr.set(att, att.getMapping().mapString(val));
				}
			}
            else {
                
                dr.set(att, Double.NaN);            

            }
		}
	}

    
    private String extractValue(TextExtractionWrapper wrapper, TextExtractor query, WVTDocumentInfo info) throws ExtractionException {
        
        Iterator<String> values = null;
        values = wrapper.getValues(query);

        if ((values != null) && values.hasNext())
         return values.next();
        else
            return null;
        
    }
    
    /**
     * Get all attributes that should be extracted.
     * 
     */
	public Collection<Attribute> getAttributes() {
		return aqMap.getAttributes();
	}
}
