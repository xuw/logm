/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator.extraction.util;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import com.rapidminer.example.Attribute;
import com.rapidminer.example.table.DataRow;
import com.rapidminer.operator.extraction.ExtractionException;
import com.rapidminer.operator.extraction.FeatureExtractor;

import edu.udo.cs.wvtool.main.WVTDocumentInfo;

/**
 * Concatenates two feature extractors.
 * 
 * @author Michael Wurst
 * @version $Id: ConcatanatedFeatureExtractor.java,v 1.1 2007/05/27 21:45:36 ingomierswa Exp $
 *
 */
public class ConcatanatedFeatureExtractor implements FeatureExtractor {

    private final FeatureExtractor[] extractors;

    /**
     * Initialize.
     * 
     * @param extractors the extractors to be concatanated.
     */
    public ConcatanatedFeatureExtractor(FeatureExtractor[] extractors) {
        super();
        this.extractors = extractors;
    }

    public void extract(WVTDocumentInfo info, DataRow dr)  throws ExtractionException {
        for(int i = 0; i < extractors.length; i++)
            extractors[i].extract(info, dr);
    }

    public Collection<Attribute> getAttributes() {
        
        List<Attribute> result = new LinkedList<Attribute>();
        for(int i = 0; i < extractors.length; i++)
            result.addAll(extractors[i].getAttributes());
        
        return result;
    }

}
