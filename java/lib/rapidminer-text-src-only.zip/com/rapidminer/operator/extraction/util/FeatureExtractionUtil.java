/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator.extraction.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.PatternSyntaxException;

import org.jaxen.JaxenException;

import com.rapidminer.example.Attribute;
import com.rapidminer.example.table.AttributeFactory;
import com.rapidminer.operator.UserError;
import com.rapidminer.operator.extraction.AttributeQueryMap;
import com.rapidminer.operator.extraction.ExtractionException;
import com.rapidminer.operator.extraction.RegexExtractor;
import com.rapidminer.operator.extraction.TextExtractor;
import com.rapidminer.operator.extraction.XPathExtractor;
import com.rapidminer.parameter.ParameterType;
import com.rapidminer.parameter.ParameterTypeList;
import com.rapidminer.parameter.ParameterTypeString;
import com.rapidminer.parameter.Parameters;
import com.rapidminer.parameter.UndefinedParameterError;
import com.rapidminer.tools.Ontology;


/**
 * Class that provides common functionality to extract a set of values based on a list of feature names and extraction patterns.
 * 
 * @author Michael Wurst
 * @version $Id: FeatureExtractionUtil.java,v 1.2 2007/07/19 13:49:05 mjwurst Exp $
 * 
 */

public class FeatureExtractionUtil {

    /**
     * Generates the list parameter.
     * 
     * @return a parameter
     */
    public static ParameterType createQueryParameter() {

        return new ParameterTypeList("attributes", "Specifies a list of attribute names and extraction queries. These queries can be XPath or a regular expression. If a regular expression is used, the query must have the following form: '<regex-expression> <replacement-pattern>', where the <replacement_pattern> states how a match is replaced to generate the final information. '$1' would yield the first matching group as result. A number sign in front of an attribute name marks the attribute as numeric. In these cases, the operator uses different heuristicts to parse a number from the extracted string. For both XPath and regex, only the first match is used.", new ParameterTypeString("query_expr", "query expression: either ?<xpath> where <xpath> is an XPath expression or <regex> <target> where <regex> is a regular expression and target is a string referencing the match, e.g. \"[0-9]+\\sEuro $1\"", false));

    }

    /**
     * Generates the namespace parameter.
     * 
     * @return a parameter
     */
    public static ParameterType createNamespaceParameter() {

        return new ParameterTypeList("namespaces", "Specifies pairs of identifier and namespace for use in XPath queries. The namespace for (x)html is bound automatically to the identifier h.", 
                new ParameterTypeString("name_space", "An id and the namespace to which it should be bound.", false));

    }
    
    /**
     * Converts a parameter list with namespace bindings to a mapping of such.
     * 
     * @param params the parameters as obtained from the operator
     * @return a map that assignes to each id the namespace it should bind to
     */
    public static Map<String,String> getNamespaceMapping(Parameters params) {
        
        List nameSpaceParameterList = null;
        try {
            nameSpaceParameterList = (List) params.getParameter("namespaces");
        } catch (UndefinedParameterError e) {
           // This should never happen :-)
        }
        
        if(nameSpaceParameterList != null) {
        Map<String, String> result = new HashMap<String, String>();
        
        for (Object entry : nameSpaceParameterList) {
            Object[] pair = (Object[]) entry;
            result.put((String) pair[0], (String) pair[1]);
        }

        return result;
        }
        else
            return new HashMap<String,String>();
    }
    
    
    /**
     * Generates a map containing pairs of attribute and extraction expression. If a feature name starts with '#' it is assumed that the feature is numerical and the '#' is deleted from the final feature name. All other features are assumed to be nominal.
     * 
     * @param params the parameters obtained from the operator
     * @return a map
     */
    public static AttributeQueryMap getAttributeQueryMap(Parameters params) throws ExtractionException {

        Map<String,String> namespaceMap = getNamespaceMapping(params);
        
        List requests = null;
        try {
            requests = (List) params.getParameter("attributes");
        } catch (UndefinedParameterError e) {
            // This should never happen 
         }
        
        if(requests != null) {
        
        AttributeQueryMap result = new AttributeQueryMap();

        for (Object entry : requests) {
            Object[] pair = (Object[]) entry;

            Attribute newAttribute = null;

            String attributeStr = (String) pair[0];
            if (attributeStr.charAt(0) == '#')
                newAttribute = AttributeFactory.createAttribute(attributeStr.substring(1), Ontology.NUMERICAL);
            else
                newAttribute = AttributeFactory.createAttribute(attributeStr, Ontology.NOMINAL);

            String query = (String) pair[1];
            
            TextExtractor extractor = getExtractor(query, namespaceMap);
            if(extractor != null)
                result.addQuery(newAttribute, extractor);
            
        }

        return result;
        }
        else
            return new AttributeQueryMap();
    }

    /**
     * Creates a TextExtractor from a query. If the first char of the query is '/' the query
     * is assumed to be a xpath query, otherwise it is assumed to be regex query.
     * 
     * @param query the query 
     * @param namespaceMap a namespace map for xpath queries (can be null for regex queries)
     * @return an extractor
     */
    public static TextExtractor getExtractor(String query, Map<String,String> namespaceMap) throws ExtractionException {
                
        if (query.charAt(0) == '/') {

            XPathExtractor xpe = null;
            try {
                xpe = new XPathExtractor(query, namespaceMap);
            } catch (JaxenException e) {
                
                throw new ExtractionException("", e, new UserError(null,211,new Object[] {query,e}));
                           }
    
            if (xpe != null)
                return xpe;

        } else {

                RegexExtractor extr = null;
                try {
                    extr = new RegexExtractor(query);
                } catch (PatternSyntaxException e) {
                    throw new ExtractionException("", e, new UserError(null,206,new Object[] {query, e}));
                    
                }

                if (extr != null)
                    return extr;
        }
        return null;
    }
    
    
}
