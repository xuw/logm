/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator.extraction.segmenter;

import java.io.InputStream;
import java.util.Iterator;

import com.rapidminer.operator.extraction.ExtractionException;
import com.rapidminer.operator.extraction.TextExtractionWrapper;
import com.rapidminer.operator.extraction.XPathExtractor;


/**
 * Segments a text based on an xpath query. Each matched element and all its descentants!
 * are used as segement
 * 
 * @author Michael Wurst
 * @version $Id: XPathSegmenter.java,v 1.1 2007/05/27 21:45:37 ingomierswa Exp $
 *
 */
public class XPathSegmenter implements DocumentSegmenter {

    private XPathExtractor extractor;
     
    public XPathSegmenter(XPathExtractor extractor) {
        super();
        this.extractor = extractor;
    }

    public Iterator<String> getSegements(String s, int type)  throws ExtractionException {
        
        TextExtractionWrapper wrapper = new TextExtractionWrapper(s, type);

        return wrapper.getValues(extractor);
     
    }

    
        public Iterator<String> getSegements(InputStream in, int type)  throws ExtractionException {
        
        TextExtractionWrapper wrapper = new TextExtractionWrapper(in, type);
        return wrapper.getValues(extractor);
        
    }
    
}
