/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator.extraction;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.Iterator;

import edu.udo.cs.wvtool.config.WVTConfiguration;
import edu.udo.cs.wvtool.generic.inputfilter.WVTInputFilter;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.util.WVToolException;

/**
 * An input filter that selects only portions of the original document
 * based on regular expression or xpath. All matching regions are 
 * concatanated and then send as stream to the next processing step. 
 * 
 * @author Michael Wurst
 * @version $Id: ExtractingInputFilter.java,v 1.1 2007/05/27 21:45:35 ingomierswa Exp $
 *
 */
public class ExtractingInputFilter implements WVTInputFilter {

    private final TextExtractor extractor; 
    private final WVTConfiguration config;
    
    /**
     * Create a new instance.
     * 
     * @param config the used WVTool configuration
     * @param extractor the text extractor
     */
    public ExtractingInputFilter(WVTConfiguration config, TextExtractor extractor) {
        super();
        this.config = config;
        this.extractor = extractor;
    }


    public Reader convertToPlainText(InputStream inStream, WVTDocumentInfo d) throws WVToolException {
      
        try {
            inStream.close();
        } catch (IOException e1) {
        // Nothing needs to be done here         
        }
        
        StringBuffer text = new StringBuffer();
        try {
            TextExtractionWrapper extractionWrapper = new TextExtractionWrapper(d, config);
            Iterator<String> values = extractionWrapper.getValues(extractor);
            
            while(values.hasNext()) {
                text.append(values.next()); text.append(' ');
            }
        
        } catch (ExtractionException e) {
            throw new WVToolException("Could not extract main text from file " + d.getSourceName(), e); 
        }
        
        return new StringReader(text.toString());
    }

}
