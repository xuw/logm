/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;

import websphinx.DownloadParameters;
import websphinx.Link;

import com.rapidminer.example.Attribute;
import com.rapidminer.example.ExampleSet;
import com.rapidminer.example.table.ListDataRowReader;
import com.rapidminer.example.table.MemoryExampleTable;
import com.rapidminer.gui.properties.PropertyTable;
import com.rapidminer.operator.crawler.CrawlerPolicyProperties;
import com.rapidminer.operator.crawler.LinkMatrix;
import com.rapidminer.operator.crawler.ParameterTypeCrawlerPolicy;
import com.rapidminer.operator.crawler.RapidMinerBasedCrawler;
import com.rapidminer.operator.crawler.StringMatchingLiteral;
import com.rapidminer.operator.crawler.StringMatchingRuleSet;
import com.rapidminer.parameter.ParameterType;
import com.rapidminer.parameter.ParameterTypeBoolean;
import com.rapidminer.parameter.ParameterTypeDirectory;
import com.rapidminer.parameter.ParameterTypeInt;
import com.rapidminer.parameter.ParameterTypeList;
import com.rapidminer.parameter.ParameterTypeString;


/**
 * 
 * This operator crawls the net and stores pages to a local directory. It allows to specify diverse rules to 
 * determine which links to visit and which pages to store. See the the WVTool Tutorial for details.
 * Notice: This operator is currently in an experimental state, use with care.
 * 
 * @author Michael Wurst
 * @version $Id: CrawlerOperator.java,v 1.2 2007/07/19 13:49:05 mjwurst Exp $
 * 
 */

public class CrawlerOperator extends Operator {

    static {
        PropertyTable.registerPropertyKeyCellEditor(ParameterTypeCrawlerPolicy.class, CrawlerPolicyProperties.class);  
        
    }
    
    public CrawlerOperator(OperatorDescription description) {
        super(description);
    }

    public IOObject[] apply() throws OperatorException {

        // Parse rules
        Map<String, StringMatchingRuleSet> rules = new HashMap<String, StringMatchingRuleSet>();

        List visitLinkRules = getParameterList("crawling_rules");

        for (Object param : visitLinkRules) {

            String key = (String) ((Object[]) param)[0];
            String rule = (String) ((Object[]) param)[1];

            List<StringMatchingLiteral> conj = new LinkedList<StringMatchingLiteral>();
            StringTokenizer ruleTokens = new StringTokenizer(rule, " ");

            while (ruleTokens.hasMoreTokens()) {

                String literal = ruleTokens.nextToken();
                boolean negation = false;
                if (literal.charAt(0) == '-') {
                    negation = true;
                    literal = literal.substring(1);
                }

                conj.add(new StringMatchingLiteral(literal, negation));

            }

            StringMatchingRuleSet ruleSet = rules.get(key);
            if (ruleSet == null) {

                ruleSet = new StringMatchingRuleSet();
                rules.put(key, ruleSet);

            }

            ruleSet.addConjunction(conj);

        }
                
        // Create crawler
        RapidMinerBasedCrawler crawler = new RapidMinerBasedCrawler(rules, getParameterAsFile("output_dir"), getParameterAsInt("delay"), this);
        DownloadParameters downloadParams = crawler.getDownloadParameters();
        downloadParams.changeMaxThreads(getParameterAsInt("max_threads"));
        downloadParams.changeObeyRobotExclusion(getParameterAsBoolean("obey_robot_exclusion"));
        downloadParams.changeUserAgent(getParameterAsString("user_agent"));
        crawler.setDownloadParameters(downloadParams);

        int robotsDialogResult = -1;
        if(!getParameterAsBoolean("obey_robot_exclusion")) {
            
            robotsDialogResult = JOptionPane.showInternalConfirmDialog(null, "You disabled the support the robots.txt. Do this only if you know what you are doing and if you are sure not to violate any laws or terms of use. Do you wish to proceed?", "Warning: Disabled robot exclusion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            
        }

        if(robotsDialogResult == JOptionPane.NO_OPTION) {
            logNote("Crawling operation aborded by the user");
            return new IOObject[0];
        }
        
        crawler.setMaxDepth(getParameterAsInt("max_depth"));

        // Prepare example table
        
        MemoryExampleTable et = new MemoryExampleTable(crawler.getCrawlerExtractedAttributes());
        
        
        // Add roots

        String url = getParameterAsString("url");

        try {
            crawler.setRoot(new Link(url));
            crawler.run();
        } catch (MalformedURLException e) {
           
            throw new UserError(this, 212, new Object[] {url, e});

        }
        et.readExamples(new ListDataRowReader(crawler.getDataRows().iterator()));

        ExampleSet es = et.createExampleSet(new HashMap<Attribute,String>());
        
        LinkMatrix linkMatrix = crawler.getLinkMatrix();
        
        return new IOObject[] {es, linkMatrix};
    }

    public Class[] getInputClasses() {
        return new Class[0];
    }

    public Class[] getOutputClasses() {
        return new Class[]{ExampleSet.class};
    }

    public List<ParameterType> getParameterTypes() {
        List<ParameterType> types = new LinkedList<ParameterType>();

        types.addAll(super.getParameterTypes());

        ParameterType type = new ParameterTypeString("url", "Specifies the url at which the crawler should start", false);
        type.setExpert(false);
        types.add(type);

        type = new ParameterTypeList("crawling_rules", "Specifies a set of rules that determine, which links to follow and which pages to process (see tutorial for details)", new ParameterTypeCrawlerPolicy("property", "the value of the property"));
        type.setExpert(false);
        types.add(type);

        type = new ParameterTypeInt("max_depth", "Specifies the maximal depth of the crawling process", 0, (int) Double.POSITIVE_INFINITY, 2);
        type.setExpert(false);
        types.add(type);

        type = new ParameterTypeInt("delay", "Specifies the delay when vistiting a page in milleseconds", 0, (int) Double.POSITIVE_INFINITY, 1000);
        type.setExpert(false);
        types.add(type);

        type = new ParameterTypeInt("max_threads", "Specifies the number of crawling threads working in parallel", 1, (int) Double.POSITIVE_INFINITY, 1);
        type.setExpert(true);
        types.add(type);

        type = new ParameterTypeDirectory("output_dir", "Specifies the directory to which to write the files", false);
        type.setExpert(false);
        types.add(type);

        type = new ParameterTypeString("user_agent", "The identity the crawler uses while accessing a server", "rapid-miner-crawler");
        type.setExpert(true);
        types.add(type);

        type = new ParameterTypeBoolean("obey_robot_exclusion", "Specifies whether the crawler obeys the rules, which pages on site might be visited by a robot. Disable only if you know what you are doing and if you a sure not to violate any existing laws by doing so", true);
        type.setExpert(true);
        types.add(type);

     //   type = new ParameterTypeString("segmenter_pattern", "Specifies a regular expression or XPath expression that matches against substrings of the content which should be treated as individual segments. The syntax is the same as for attribute extraction (see WVTool operator), but instead of extracting only the first match, all matches are extracted and written to individual files", true);
     //   type.setExpert(true);
     //   types.add(type);

        return types;
    }
    
}
