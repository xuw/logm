package com.rapidminer.operator.reducer;

import com.rapidminer.operator.AbstractTokenProcessor;
import com.rapidminer.operator.OperatorDescription;

import edu.udo.cs.wvtool.generic.stemmer.LovinsStemmerWrapper;
import edu.udo.cs.wvtool.generic.stemmer.WVTStemmer;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.util.TokenEnumeration;
import edu.udo.cs.wvtool.util.WVToolException;

/**
 * The Lovinsstemmer for english texts.
 * 
 * @author Michael Wurst
 * @version $Id$
 *
 */
public class LovinsStemmer extends AbstractTokenProcessor {

    WVTStemmer stemmer = new LovinsStemmerWrapper();
    
    public LovinsStemmer(OperatorDescription description) {
        super(description);
    }

    protected TokenEnumeration process(TokenEnumeration tokens, WVTDocumentInfo docInfo) throws WVToolException {
        return stemmer.stem(tokens, docInfo);
    }

}
