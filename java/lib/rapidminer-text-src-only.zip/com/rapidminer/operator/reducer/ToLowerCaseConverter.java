package com.rapidminer.operator.reducer;

import com.rapidminer.operator.AbstractTokenProcessor;
import com.rapidminer.operator.OperatorDescription;

import edu.udo.cs.wvtool.generic.stemmer.WVTStemmer;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.util.TokenEnumeration;
import edu.udo.cs.wvtool.util.WVToolException;

/**
 * Converts the characters in all terms to lower case.
 * 
 * @author Michael Wurst
 * @version $Id$
 *
 */
public class ToLowerCaseConverter extends AbstractTokenProcessor {

    private WVTStemmer stemmer = new edu.udo.cs.wvtool.generic.stemmer.ToLowerCaseConverter();
    
    public ToLowerCaseConverter(OperatorDescription description) {
        super(description);
    }

    protected TokenEnumeration process(TokenEnumeration tokens, WVTDocumentInfo docInfo) throws WVToolException {

        return stemmer.stem(tokens, docInfo);
    }

}
