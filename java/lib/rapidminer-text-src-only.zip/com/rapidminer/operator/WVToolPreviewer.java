/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.AbstractListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;

import com.rapidminer.Process;
import com.rapidminer.example.Attribute;
import com.rapidminer.example.table.DataRow;
import com.rapidminer.example.table.DoubleSparseArrayDataRow;
import com.rapidminer.example.table.MemoryExampleTable;
import com.rapidminer.gui.RapidMinerGUI;
import com.rapidminer.gui.wizards.PreviewListener;
import com.rapidminer.operator.extraction.AttributeQueryMap;
import com.rapidminer.operator.extraction.DefaultFeatureExtractor;
import com.rapidminer.operator.extraction.ExtractionException;
import com.rapidminer.operator.extraction.util.FeatureExtractionUtil;
import com.rapidminer.parameter.Parameters;
import com.rapidminer.tools.OperatorService;

import edu.udo.cs.wvtool.config.WVTConfiguration;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.main.WVTFileInputList;
import edu.udo.cs.wvtool.main.WVTool;
import edu.udo.cs.wvtool.util.WVToolException;

/**
 * Allows to preview the output of the wvtool operator.
 * 
 * @author Michael Wurst
 * @version $Id: WVToolPreviewer.java,v 1.5 2007/07/02 16:14:47 ingomierswa Exp $
 * 
 */
public class WVToolPreviewer extends JDialog implements ListSelectionListener {

    private static final long serialVersionUID = 8889036332147144390L;

    private String errorMessages = "You must specify at least one directory containing at least on text in \"texts\"";

    private final JTextArea textAreaOriginal;

    private final JList selectorList;
    
    private final FeaturesTableModel model;

    private final Parameters params;

    private final DocumentSelectorListModel listModel = new DocumentSelectorListModel();

    private WVTConfiguration config;
    
    public WVToolPreviewer(PreviewListener listener) {
        super(RapidMinerGUI.getMainFrame(), "WVTool Previewer", true);
       
        textAreaOriginal = new JTextArea();
        textAreaOriginal.setWrapStyleWord(true);
        textAreaOriginal.setLineWrap(true);
        textAreaOriginal.setMargin(new Insets(10, 10, 10, 10));

        model = new FeaturesTableModel();
        final JTable featureTable = new JTable();
        featureTable.setModel(model);

        selectorList = new JList();
        selectorList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        selectorList.addListSelectionListener(this);
        
        selectorList.setModel(listModel);
        
        JButton okButton = new JButton("Close");
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                dispose();
            }
        });

        getContentPane().setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1;
        gbc.weighty = 1;

        GridBagConstraints gbcLabel = new GridBagConstraints();
        gbcLabel.gridx = 0;
        gbcLabel.gridy = GridBagConstraints.RELATIVE;
        gbcLabel.fill = GridBagConstraints.HORIZONTAL;
        gbcLabel.weightx = 1;
        gbcLabel.weighty = 0;
        gbcLabel.insets = new Insets(10,10,10,10);
        
        JLabel label = new JLabel("Select a document");
        label.setFont(label.getFont().deriveFont(Font.BOLD));
        getContentPane().add(label, gbcLabel);
        getContentPane().add(new JScrollPane(selectorList), gbc);
        label = new JLabel("Original text");
        label.setFont(label.getFont().deriveFont(Font.BOLD));
        getContentPane().add(label, gbcLabel);
        getContentPane().add(new JScrollPane(textAreaOriginal), gbc);
        label = new JLabel("Stream of processed tokens");
        label.setFont(label.getFont().deriveFont(Font.BOLD));
        getContentPane().add(label, gbcLabel);
        label = new JLabel("Extracted features");
        label.setFont(label.getFont().deriveFont(Font.BOLD));
        getContentPane().add(label, gbcLabel);
        getContentPane().add(new JScrollPane(featureTable), gbc);

        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        gbc.weighty = 0;
        gbc.insets = new Insets(7, 7, 7, 7);
        getContentPane().add(okButton, gbc);

        setSize(Math.max(640, (int) (0.66d * getOwner().getWidth())), Math.max(480, (int) (0.66d * getOwner().getHeight())));

        setLocationRelativeTo(getOwner());

        params = listener.getParameters();

        try {
            Process process = listener.getProcess();
            
            FeatureExtractionOperator w = null;
            w = OperatorService.createOperator(FeatureExtractionOperator.class);
            if(process != null)
                w.setExternalExperiment(process);
            
            
            w.setParameters(listener.getParameters());
            
            
            List textList = (List) listener.getParameters().getParameter("texts");
            if ((textList != null) && (textList.size() > 0)) {

                config = new WVTConfiguration();

                WVTFileInputList inputList = (WVTFileInputList) w.createInputList();
                
                Iterator it = inputList.getEntries(true);

                while(it.hasNext()) {
                    listModel.addEntry((WVTDocumentInfo) it.next());
                }
                
                if (listModel.getSize() > 0) {

                    WVTDocumentInfo testDocument = listModel.getDocInfoAt(0);
                    selectorList.setSelectedIndex(0);
                    openTextDocument(testDocument);
                } else {
                    textAreaOriginal.setText(errorMessages);
                }
            } else {
                textAreaOriginal.setText(errorMessages);
            }

        } catch (OperatorCreationException e) {
            textAreaOriginal.setText(errorMessages);
        } catch (OperatorException e) {
            textAreaOriginal.setText(errorMessages);
        }
    }

    private void openTextDocument(WVTDocumentInfo testDocument) {

        try {

            WVTFileInputList inputList2 = new WVTFileInputList(0);
            inputList2.addEntry(testDocument);

            WVTool wvt = new WVTool(false);
 
            BufferedReader origIn = new BufferedReader(wvt.getReader(testDocument, config));
            StringBuffer originalText = new StringBuffer();
            String buf = null;
            while ((buf = origIn.readLine()) != null) {
                originalText.append(buf);
                originalText.append("\n");
            }
            
            textAreaOriginal.setText(originalText.toString());

            AttributeQueryMap aqMap = FeatureExtractionUtil.getAttributeQueryMap(params);
            
            new MemoryExampleTable(aqMap.getAttributes());
            
            DefaultFeatureExtractor defaultExtractor = new DefaultFeatureExtractor(aqMap, config);
            
            DataRow row = new DoubleSparseArrayDataRow(aqMap.getAttributes().size());
            
            defaultExtractor.extract(testDocument, row);
            
            for (Attribute att : aqMap.getAttributes()) {
               if(!Double.isNaN(row.get(att))) {
                if(att.isNominal())
                    model.putValue(att.getName(), att.getMapping().mapIndex((int) row.get(att)));
                else
                    model.putValue(att.getName(), row.get(att) + "");
                }
                
                else
                    model.putValue(att.getName(), "unknown");

            }
        } catch (IOException e) {
            textAreaOriginal.setText(errorMessages);
        } catch (ExtractionException e) {
            textAreaOriginal.setText(errorMessages);
          
        } catch (WVToolException e) {
            textAreaOriginal.setText(errorMessages);
        }
        textAreaOriginal.setCaretPosition(0);
    }

    public void valueChanged(ListSelectionEvent arg0) {
     
        int index = selectorList.getSelectedIndex();
        if(index >= 0)
            openTextDocument(listModel.getDocInfoAt(index));
        
    }
}

/**
 * Table used to show extracted features
 * 
 * @author Michael Wurst
 * @version $Id: WVToolPreviewer.java,v 1.5 2007/07/02 16:14:47 ingomierswa Exp $
 * 
 */
class FeaturesTableModel extends AbstractTableModel {

    private static final long serialVersionUID = -17872022872313061L;

    private Map<String, String> entries = new HashMap<String, String>();

    private List<String> attNames = new ArrayList<String>();

    public String getColumnName(int index) {

        switch (index) {
        case 0:
            return "feature name";
        case 1:
            return "feature value";
        default: return null;
        }
    }

    public boolean isCellEditable(int arg0, int arg1) {

        return false;
    }

    public void setValueAt(Object arg0, int arg1, int arg2) {

    }

    public int getColumnCount() {

        return 2;
    }

    public int getRowCount() {
        return attNames.size();
    }

    public Object getValueAt(int rowIndex, int columnIndex) {

        String attName = attNames.get(rowIndex);
        String value = entries.get(attName);

        if (columnIndex == 0)
            return attName;
        else
            return value;
    }

    public void putValue(String attName, String value) {

        if (entries.get(attName) == null)
            attNames.add(attName);

        entries.put(attName, value);

        fireTableStructureChanged();
        fireTableDataChanged();

    }

}

/**
 * List for the selection of the current document.
 * 
 * @author Michael Wurst
 * @version $Id: WVToolPreviewer.java,v 1.5 2007/07/02 16:14:47 ingomierswa Exp $
 *
 */
class DocumentSelectorListModel extends AbstractListModel {

    /**
     * 
     */
    private static final long serialVersionUID = 4439989297252666633L;
    private List<WVTDocumentInfo> docList = new ArrayList<WVTDocumentInfo>();
    
    public Object getElementAt(int nr) {
       
        return docList.get(nr).getSourceName();
    }

    public WVTDocumentInfo getDocInfoAt(int nr) {
        
        return docList.get(nr);
    }
    
    public int getSize() {
        return docList.size();
    }
    
    public void addEntry(WVTDocumentInfo docInfo) {
        docList.add(docInfo);
        fireIntervalAdded(this, 0, getSize()-1);
    }
    
    
}
