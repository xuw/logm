/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.util.LinkedList;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.AbstractTableModel;

import com.rapidminer.Process;
import com.rapidminer.gui.RapidMinerGUI;
import com.rapidminer.gui.wizards.AbstractConfigurationWizard;
import com.rapidminer.gui.wizards.ConfigurationListener;
import com.rapidminer.parameter.Parameters;
import com.rapidminer.parameter.UndefinedParameterError;

import edu.udo.cs.wvtool.generic.inputfilter.WVTInputFilter;
import edu.udo.cs.wvtool.generic.loader.UniversalLoader;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;


/**
 * Wizard that helps to configure the WVTool operator. Currently, source, language and input wordlist selection are supported.
 * 
 * @author Michael Wurst
 * @version $Id: WVToolConfigurationWizard.java,v 1.2 2007/06/07 17:12:36 ingomierswa Exp $
 * 
 */


public class WVToolConfigurationWizard extends AbstractConfigurationWizard {

    private static final long serialVersionUID = 2852889200016145801L;

    private final FileChooserTextField singleDirChooser = new FileChooserTextField(this, true);

    private final LabelRadioButton singleDirSelector = new LabelRadioButton("Specify a single directory with text documents");

    private final LabelRadioButton classSelector = new LabelRadioButton(
            "Specify a directory with text documents for each class");

    private final TextSourceTableModel tableModel = new TextSourceTableModel();

    private final FileChooserTextField fileChooser = new FileChooserTextField(this, false);

    private final LabelRadioButton fileChooserSelector = new LabelRadioButton("Select a previously created word list");

    private final LabelRadioButton noWordListSelector = new LabelRadioButton(
            "Create the word list automatically from the texts");

    private final String[] languages = { "english", "other/mixed", "german", "danish", "dutch", "finnish", "french", "italian",
            "norwegian", "portuguese", "russian", "spanish", "swedish" };

    private String selectedLanguage = languages[0];
    private final JComboBox languageBox = new JComboBox(languages);
    
    
    private WVTDocumentInfo previewDocInfo = null;

    private final UniversalLoader loader = new UniversalLoader();

    private final static int PREVIEW_LINES = 100;

    private final String[] inputFilterClassNames = { "edu.udo.cs.wvtool.generic.inputfilter.TextInputFilter",
            "edu.udo.cs.wvtool.generic.inputfilter.XMLInputFilter" };

    private final JTextArea previewArea = new JTextArea(10, 20);

    private final JComboBox filterSelector = new JComboBox(inputFilterClassNames);

    private final Process process;
    
    public WVToolConfigurationWizard(ConfigurationListener listener) {
        super("WVTool Configuration Wizard", listener);

        JPanel panel = new JPanel();

        process = listener.getProcess();
        
        panel.add(new JLabel("This Wizard will guide you through configuring the wvtool"));
        addSourceSelectionStep(listener.getParameters());
//        addFilterSelectionStep(listener.getParameters());
        addLanguageSelectionStep(listener.getParameters());
        addWordListSelectionStep(listener.getParameters());
    }

    protected void performStepAction(int currentStep, int oldStep) {

        previewDocInfo = null;

        if ((currentStep > 0) && (currentStep < 3)) {

            try {
                String dirName = null;
                if (singleDirSelector.getButton().isSelected())
                    dirName = singleDirChooser.getTextField().getText();
                else if (tableModel.getRowCount() > 0)
                    dirName = (String) tableModel.getValueAt(0, 1);

                if (dirName != null) {
                    File dir = new File(dirName);
                    File[] files = dir.listFiles(new FileFilter() {
                        public boolean accept(File arg0) {
                            return arg0.isFile();
                        }
                    });

                    if ((files != null) && (files.length > 0))
                        previewDocInfo = new WVTDocumentInfo(files[0].getCanonicalPath(), "", "", "");
                }
            } catch (Exception e) {
                previewDocInfo = null;
            }
            updatePreviewText();
        }

    }

    protected void finish(ConfigurationListener listener) {

        Parameters parameters = listener.getParameters();

        // Source parameters

        List<String[]> texts = new LinkedList<String[]>();

        if (singleDirSelector.getButton().isSelected())
            texts.add(new String[] { "texts", singleDirChooser.getTextField().getText() });
        else
            for (int i = 0; i < tableModel.getRowCount(); i++)
                texts.add(new String[] { (String) tableModel.getValueAt(i, 0), (String) tableModel.getValueAt(i, 1) });

        parameters.setParameter("texts", texts);

        // Language parameters
        if (!selectedLanguage.equals("other/mixed")) {
            parameters.setParameter("default_content_language", selectedLanguage);
            parameters.setParameter("stemmer", "SnowballStemmerWrapper");
            if (selectedLanguage.equals("english")) {
                parameters.setParameter("stemmer", "LovinsStemmerWrapper");
                parameters.setParameter("wordfilter", "StopWordsWrapper");
            } else if (selectedLanguage.equals("french")) {
                parameters.setParameter("wordfilter", "StopwordsFrench");
            } else if (selectedLanguage.equals("german")) {
                //parameters.setParameter("stemmer", "DummyStemmer");
                parameters.setParameter("wordfilter", "StopWordsWrapperGerman");
            } else {
                //parameters.setParameter("stemmer", "DummyStemmer");
                parameters.setParameter("wordfilter", "DummyWordFilter");
            }
        } else {
            parameters.setParameter("default_content_language", "");
            parameters.setParameter("stemmer", "DummyStemmer");
            parameters.setParameter("wordfilter", "DummyWordFilter");
            parameters.setParameter("min_chars", "2");
        }

        // Input word list
        if (!noWordListSelector.getButton().isSelected())
            parameters.setParameter("input_word_list", fileChooser.getTextField().getText());
        else
            parameters.setParameter("input_word_list",null);
        
        // Input filter
        ClassNameMapper inputFilterMapper = new ClassNameMapper(inputFilterClassNames);
        parameters.setParameter("inputfilter",
                inputFilterMapper.getShortClassNames()[filterSelector.getSelectedIndex()]);

        listener.setParameters(parameters);

        dispose();
        RapidMinerGUI.getMainFrame().getPropertyTable().refresh();

    }

    private void addSourceSelectionStep(Parameters parameters) {

        // Import parameters
        boolean singleDir = true;
        List textList;
        try {
            textList = (List) parameters.getParameter("texts");
        } catch (UndefinedParameterError e) {
            textList = null;
        }
        if((textList != null)&&(textList.size() > 0)) {
            singleDir = false;
            for(Object entry: textList) {
                Object[] pair = (Object[]) entry;
                
                if((textList.size() == 1)&&(pair[0].equals("texts"))) {
                    
                    File file = process.resolveFileName((String) pair[1]);
                   
                    singleDirChooser.getTextField().setText(file.getAbsolutePath());
                    singleDir = true;
                }
                else {
                    
                    File file = process.resolveFileName((String) pair[1]);
                    
                    tableModel.addRow((String) pair[0], file);
                }
            }
        }
        
        
        final JPanel sourceSelectionPanel = new JPanel();
        sourceSelectionPanel.setLayout(new GridBagLayout());
        
        ButtonGroup selectorGroup = new ButtonGroup();

        // Single dir chooser
        selectorGroup.add(singleDirSelector.getButton());
        
        if(singleDir)
            singleDirSelector.getButton().setSelected(true);
        else
            classSelector.getButton().setSelected(true);
        // Individual class chooser
        selectorGroup.add(classSelector.getButton());
            
        
        final JTable classTable = new JTable(tableModel);
        classTable.setPreferredScrollableViewportSize(new Dimension(80, 150));

        JPanel classTablePanel = new JPanel(new BorderLayout());
        classTablePanel.add(classTable, BorderLayout.CENTER);

        JPanel tableEditButtons = new JPanel(new FlowLayout(FlowLayout.LEADING));
        final JButton addClassButton = new JButton("Add...");
        addClassButton.setToolTipText("Add a single directory with text documents");
        
        addClassButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent arg0) {

                try {
                    FileChooserTextField dirField = new FileChooserTextField(sourceSelectionPanel, true);

                    JPanel classPanel = new JPanel(new GridBagLayout());
                    GridBagConstraints gbc = new GridBagConstraints();
                    gbc.gridy = 0; gbc.gridx = GridBagConstraints.RELATIVE;
                    gbc.gridwidth = 2; gbc.gridheight = 1;
                    gbc.fill = GridBagConstraints.NONE;
                    gbc.anchor = GridBagConstraints.WEST;
                    
                    classPanel.add(new JLabel("Class name: "), gbc);
                    JTextField classField = new JTextField();
                    gbc.fill = GridBagConstraints.HORIZONTAL;gbc.weightx = 1;
                    classPanel.add(classField, gbc);

                    JPanel dirPanel = new JPanel(new BorderLayout());
                    dirPanel.add(new JLabel("Directory:      "), BorderLayout.WEST);
                    dirPanel.add(dirField, BorderLayout.CENTER);

                    JPanel classAddingPane = new JPanel(new GridLayout(0, 1));
                    classAddingPane.add(classPanel);
                    classAddingPane.add(dirPanel);

                    int result = JOptionPane.showConfirmDialog(sourceSelectionPanel, classAddingPane, "Add a class",
                            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                    if (result == JOptionPane.OK_OPTION) {
                        
                        File file = new File(dirField.getTextField().getText());
                        
                        if(file.exists())
                            tableModel.addRow(classField.getText(), file);
                        
                    }
                } catch (Exception e) {
                       // Do not do anything here
                }
            }
        });

        final JButton delClassButton = new JButton("Remove");
        delClassButton.setToolTipText("Remove the selected directory");
        delClassButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent arg0) {
                int rowIndex = classTable.getSelectedRow();
                if (rowIndex >= 0)
                    tableModel.delRow(rowIndex);
            }

        });

        final JButton dirClassButton = new JButton("Add all subdirectories...");
        dirClassButton.setToolTipText("Automatically add all subdirectories of a directory");
        dirClassButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent arg0) {

                try {
                    FileChooserTextField dirField = new FileChooserTextField(sourceSelectionPanel, true);

                    JPanel dirPanel = new JPanel(new BorderLayout());
                    dirPanel.add(new JLabel("Directory: "), BorderLayout.WEST);
                    dirPanel.add(dirField, BorderLayout.CENTER);

                    int result = JOptionPane.showConfirmDialog(sourceSelectionPanel, dirPanel, "Add a directory",
                            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                    if (result == JOptionPane.OK_OPTION) {

                        String dirStr = dirField.getTextField().getText();
                        File dir = new File(dirStr);
                        if ((!dir.exists())||(!dir.isDirectory())) {
                            JOptionPane.showMessageDialog(null,
                                    "The directory does not exist or is not accessible at the moment.");
                        } else {

                            int numFiles = 0;
                            int numDirectories = 0;
                            File[] files = dir.listFiles();

                            for (int i = 0; i < files.length; i++) {
                                if (files[i].isFile())
                                    numFiles++;
                                else {
                                    numDirectories++;
                                    tableModel.addRow(files[i].getName(), files[i]);
                                }

                            }

                            if (numFiles > 0)
                                JOptionPane.showMessageDialog(null,
                                        "This directory contains individual files. These will be ignored.");

                            if (numDirectories == 0)
                                JOptionPane.showMessageDialog(null, "This directory does not contain any subdirectories");

                        }
                    }
                } catch (Exception e) {
                    // Do not do anything in this case...
                }
            
            }
        });

        tableEditButtons.add(addClassButton);
        tableEditButtons.add(delClassButton);
        tableEditButtons.add(dirClassButton);

        // Put it together

        singleDirSelector.getButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                singleDirChooser.setEnabled(true);
                classTable.setEnabled(false);
                addClassButton.setEnabled(false);
                delClassButton.setEnabled(false);
                dirClassButton.setEnabled(false);
            }
        });

        classSelector.getButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                singleDirChooser.setEnabled(false);
                classTable.setEnabled(true);
                addClassButton.setEnabled(true);
                delClassButton.setEnabled(true);
                dirClassButton.setEnabled(true);
            }
        });

        if(singleDir) {
            classTable.setEnabled(false);
            addClassButton.setEnabled(false);
            delClassButton.setEnabled(false);
            dirClassButton.setEnabled(false);
        }
        else 
            singleDirChooser.setEnabled(false);

        String sourceSelectionText = new String("Select the source from which the texts are loaded. ");
        sourceSelectionText += "You can either load all texts from one directory. In this case no class information is provided. ";
        sourceSelectionText += "Secondly, you can select a directory with texts for each class separately. ";
        sourceSelectionText += "Finally, you can define a single directory containing a subdirectory with texts for each class.";
        JTextArea sourceSelectionTextArea = new JTextArea(10, 5);
        sourceSelectionTextArea.setText(sourceSelectionText);
        sourceSelectionTextArea.setBackground(sourceSelectionPanel.getBackground());
        sourceSelectionTextArea.setWrapStyleWord(true);
        sourceSelectionTextArea.setLineWrap(true);

        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new FlowLayout(FlowLayout.LEADING));
        titlePanel.add(new JLabel("<html><h1>Step 1: Source Selection</h1></html>"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.NORTHEAST;
        gbc.weightx = 1;
        gbc.insets = new Insets(7,7,7,7);
        GridBagConstraints gbcSeparator = (GridBagConstraints) gbc.clone();
        //gbcSeparator.ipady = 5;
        
        sourceSelectionPanel.add(titlePanel, gbc);
        sourceSelectionPanel.add(sourceSelectionTextArea, gbc);
        sourceSelectionPanel.add(singleDirSelector, gbc);
        sourceSelectionPanel.add(singleDirChooser, gbc);
        sourceSelectionPanel.add(new JSeparator(), gbcSeparator);
        sourceSelectionPanel.add(classSelector, gbc);
        gbc.fill = GridBagConstraints.BOTH;gbc.weighty = 1;
        sourceSelectionPanel.add(new JScrollPane(classTable), gbc);
        gbc.fill = GridBagConstraints.HORIZONTAL;gbc.weighty = 0;
        sourceSelectionPanel.add(tableEditButtons, gbc);

        addStep(sourceSelectionPanel);
    }

//    private void addFilterSelectionStep(Parameters parameters) {
//
//        // Import parameters
//        String filterClass;
//        try {
//            filterClass = (String) parameters.getParameter("inputfilter");
//        } catch (UndefinedParameterError e) {
//            filterClass = null;
//        }
//        
//        if(filterClass != null) {
//            int index = -1;
//            for(int i = 0; (i <inputFilterClassNames.length)&&(index < 0); i++)
//                if(inputFilterClassNames[i].contains(filterClass))
//                    index = i;
//        
//            if(index >= 0)
//                filterSelector.setSelectedIndex(index);
//        }
//        
//        final JPanel filterSelectionPanel = new JPanel();
//        filterSelectionPanel.setLayout(new GridBagLayout());
//
//        JPanel previewPanel = new JPanel(new BorderLayout());
//        previewPanel.add(new JLabel("Preview"), BorderLayout.NORTH);
//        previewPanel.add(new JScrollPane(previewArea), BorderLayout.CENTER);
//
//        JPanel inputFilterPanel = new JPanel(new BorderLayout());
//
//        filterSelector.addItemListener(new ItemListener() {
//
//            public void itemStateChanged(ItemEvent arg0) {
//
//                updatePreviewText();
//
//                // if (previewDocInfo != null) {
//                //
//                // try {
//                // String className = (String) filterSelector.getSelectedItem();
//                // WVTInputFilter filter = null;
//                //
//                // filter = (WVTInputFilter) Class.forName(className).newInstance();
//                //
//                // if (filter != null) {
//                //
//                // BufferedReader in = new BufferedReader(filter.convertToPlainText(loader
//                // .loadDocument(previewDocInfo), previewDocInfo));
//                // String buf = null;
//                //
//                // int counter = 0;
//                // StringBuffer previewText = new StringBuffer();
//                // while (((buf = in.readLine()) != null) && (counter < PREVIEW_LINES)) {
//                // previewText.append(buf);
//                // previewText.append("\n");
//                // counter++;
//                // }
//                // previewArea.setText(previewText.toString());
//                // previewArea.setCaretPosition(0);
//                // }
//                // } catch (Exception e) {
//                // // If it does not work, do nothing here
//                // e.printStackTrace();
//                // previewArea.setText("No preview available");
//                // }
//                // } else
//                // previewArea.setText("No preview available");
//            }
//
//        });
//
//        inputFilterPanel.add(new JLabel("Input Filter "), BorderLayout.WEST);
//        inputFilterPanel.add(filterSelector, BorderLayout.CENTER);
//
//        String languageSelectionText = new String("Please select an input filter.");
//
//        JTextArea filterSelectionTextArea = new JTextArea(10, 5);
//        filterSelectionTextArea.setText(languageSelectionText);
//        filterSelectionTextArea.setBackground(filterSelectionPanel.getBackground());
//        filterSelectionTextArea.setWrapStyleWord(true);
//        filterSelectionTextArea.setLineWrap(true);
//
//        JPanel titlePanel = new JPanel();
//        titlePanel.setLayout(new FlowLayout(FlowLayout.LEADING));
//        titlePanel.add(new JLabel("<html><h1>Step 2: Input Filter Selection</h1><html>"));
//
//        GridBagConstraints gbc = new GridBagConstraints();
//        gbc.gridx = 0; gbc.gridy = GridBagConstraints.RELATIVE;
//        gbc.gridwidth = 1;
//        gbc.fill = GridBagConstraints.HORIZONTAL;
//        gbc.anchor = GridBagConstraints.NORTHEAST;
//        gbc.weightx = 1;
//        gbc.insets = new Insets(7,7,7,7);
//        
//        filterSelectionPanel.add(titlePanel, gbc);
//        filterSelectionPanel.add(filterSelectionTextArea, gbc);
//        filterSelectionPanel.add(inputFilterPanel, gbc);
//        gbc.weighty = 1;
//        gbc.fill = GridBagConstraints.BOTH;
//        filterSelectionPanel.add(previewPanel, gbc);
//
//        addStep(filterSelectionPanel);
//
//    }

    private void addWordListSelectionStep(Parameters parameters) {

        // Import parameters
        File wordListFile;
        try {
            wordListFile = process.resolveFileName((String) parameters.getParameter("input_word_list"));
        } catch (UndefinedParameterError e) {
            wordListFile = null;
        }
        
        if(wordListFile != null)
            fileChooser.getTextField().setText(wordListFile.getAbsolutePath());
           
        final JPanel wordListSelectionPanel = new JPanel();
        wordListSelectionPanel.setLayout(new GridBagLayout());

        ButtonGroup selectorGroup = new ButtonGroup();

        // Single file chooser
        selectorGroup.add(fileChooserSelector.getButton());

        // No word list mode
        selectorGroup.add(noWordListSelector.getButton());
        
        if(wordListFile == null)
            noWordListSelector.getButton().setSelected(true);
        else
            fileChooserSelector.getButton().setSelected(true);
        
        // Put it together
        fileChooserSelector.getButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                fileChooser.setEnabled(true);
            }
        });

        noWordListSelector.getButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                fileChooser.setEnabled(false);
            }
        });

        if(wordListFile != null)
            fileChooser.setEnabled(true);
        else
            fileChooser.setEnabled(false);
        
        String wordListSelectionText = new String(
                "If you already obtained a word list with document frequencies, you can use this word list for the selected texts.");
        wordListSelectionText += "You should do this especially if you want to apply a previously learned model to a new set of texts.";

        JTextArea wordListSelectionTextArea = new JTextArea();
        wordListSelectionTextArea.setText(wordListSelectionText);
        wordListSelectionTextArea.setBackground(wordListSelectionPanel.getBackground());
        wordListSelectionTextArea.setWrapStyleWord(true);
        wordListSelectionTextArea.setLineWrap(true);

        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new FlowLayout(FlowLayout.LEADING));
        titlePanel.add(new JLabel("<html><h1>Step 4: Word List Selection</h1></html>"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.weightx = 1;gbc.weighty = 0;
        gbc.insets = new Insets(7,7,7,7);
        
        wordListSelectionPanel.add(titlePanel, gbc);
        wordListSelectionPanel.add(wordListSelectionTextArea, gbc);
        wordListSelectionPanel.add(noWordListSelector, gbc);
        wordListSelectionPanel.add(new JSeparator(), gbc);
        wordListSelectionPanel.add(fileChooserSelector, gbc);
        wordListSelectionPanel.add(fileChooser, gbc);
        gbc.fill = GridBagConstraints.BOTH; gbc.weighty = 1;
        JTextArea pseudoTextArea = new JTextArea();
        pseudoTextArea.setBackground(wordListSelectionPanel.getBackground());
        wordListSelectionPanel.add(pseudoTextArea,gbc);
        addStep(wordListSelectionPanel);
    }

    private void addLanguageSelectionStep(Parameters parameters) {

        // Import parameters
        String languageStr;
        try {
            languageStr = (String) parameters.getParameter("default_content_language");
        } catch (UndefinedParameterError e) {
           languageStr = null;
        }
        
        if(languageStr != null) {
            int index = -1;
            for(int i = 0; (i < languages.length)&&(index < 0); i++)
                if(languages[i].equalsIgnoreCase(languageStr))
                    index = i;
        
            if(index >= 0) {
                languageBox.setSelectedIndex(index);
                selectedLanguage = languages[index];
            }
        }
        
        
        final JPanel languageSelectionPanel = new JPanel();
        languageSelectionPanel.setLayout(new GridBagLayout());

       languageBox.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent arg0) {
                selectedLanguage = (String) languageBox.getSelectedItem();
            }
        });

        String languageSelectionText = new String("Please select the language the text documents are written in.");

        JTextArea languageSelectionTextArea = new JTextArea(10, 5);
        languageSelectionTextArea.setText(languageSelectionText);
        languageSelectionTextArea.setBackground(languageSelectionPanel.getBackground());
        languageSelectionTextArea.setWrapStyleWord(true);
        languageSelectionTextArea.setLineWrap(true);
        
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new FlowLayout(FlowLayout.LEADING));
        titlePanel.add(new JLabel("<html><h1>Step 3: Language Selection</h1><html>"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.weightx = 1;
        gbc.insets = new Insets(7,7,7,7);
        
        languageSelectionPanel.add(titlePanel, gbc);
        languageSelectionPanel.add(languageSelectionTextArea, gbc);
        languageSelectionPanel.add(languageBox, gbc);
        gbc.fill = GridBagConstraints.BOTH; gbc.weighty = 1;
        JTextArea pseudoTextArea = new JTextArea();
        pseudoTextArea.setBackground(languageSelectionPanel.getBackground());
        languageSelectionPanel.add(pseudoTextArea, gbc);
        addStep(languageSelectionPanel);
    }

    public void updatePreviewText() {

        if (previewDocInfo != null) {

            try {
                String className = (String) filterSelector.getSelectedItem();
                WVTInputFilter filter = null;

                filter = (WVTInputFilter) Class.forName(className).newInstance();

                if (filter != null) {

                    BufferedReader in = new BufferedReader(filter.convertToPlainText(loader
                            .loadDocument(previewDocInfo), previewDocInfo));
                    String buf = null;

                    int counter = 0;
                    StringBuffer previewText = new StringBuffer();
                    while (((buf = in.readLine()) != null) && (counter < PREVIEW_LINES)) {
                        previewText.append(buf);
                        previewText.append("\n");
                        counter++;
                    }
                    previewArea.setText(previewText.toString());
                    previewArea.setCaretPosition(0);
                }
            } catch (Exception e) {
                // If it does not work, do nothing here
                previewArea.setText("No preview available");
            }
        } else
            previewArea.setText("No preview available");
    }
}

/**
 * Table used to select text documents.
 * 
 * @author Michael Wurst
 * @version $Id: WVToolConfigurationWizard.java,v 1.2 2007/06/07 17:12:36 ingomierswa Exp $
 * 
 */
class TextSourceTableModel extends AbstractTableModel {

    private static final long serialVersionUID = -17872022872313061L;

    List<String[]> entries = new LinkedList<String[]>();

    public String getColumnName(int index) {

        switch (index) {
        case 0:
            return "class name";
        case 1:
            return "source directory";
        case 2:
            return "#texts";
        
        default: return null;  
        }
      
    }

    public boolean isCellEditable(int arg0, int arg1) {

        return false;
    }

    public void setValueAt(Object arg0, int arg1, int arg2) {

    }

    public int getColumnCount() {

        return 3;
    }

    public int getRowCount() {
        return entries.size();
    }

    public Object getValueAt(int rowIndex, int columnIndex) {

        String[] row = entries.get(rowIndex);

        return row[columnIndex];
    }

    public void addRow(String className, File dir) {

        if (!dir.exists()) {
            JOptionPane.showMessageDialog(null, "The directory " + dir.getAbsolutePath()
                    + " does not exist or is not accessible at the moment.");
            return;
        }
        int numFiles = 0;
        int numDirectories = 0;
        File[] files = dir.listFiles();

        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile())
                numFiles++;
            else
                numDirectories++;
        }

        if (numDirectories > 0)
            JOptionPane.showMessageDialog(null, "The directory " + dir.getAbsolutePath()
                    + " contains subdirectories. These directories will be ignored");

        if (numFiles == 0)
            JOptionPane.showMessageDialog(null, "The directory " + dir.getAbsolutePath()
                    + " does not contain any files.");

        entries.add(new String[] { className, dir.getAbsolutePath(), "" + numFiles });
        fireTableRowsInserted(entries.size() - 1, entries.size() - 1);

    }

    public void delRow(int rowIndex) {

        entries.remove(rowIndex);
        fireTableRowsDeleted(rowIndex, rowIndex);
    }

}

/**
 * A file chooser combined with a text field.
 * 
 * @author Michael Wurst
 * @version $Id: WVToolConfigurationWizard.java,v 1.2 2007/06/07 17:12:36 ingomierswa Exp $
 *
 */
class FileChooserTextField extends JPanel {

    private static final long serialVersionUID = -881870566556416203L;

    private final JFileChooser chooser = new JFileChooser();

    private final JTextField fileField = new JTextField();

    private final JButton fileChooserButton = new JButton("...");

    public FileChooserTextField(final Component root, final boolean dirMode) {
        super(new GridBagLayout());

        
        fileField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg) {
                fileField.setCaretPosition(0);
            }
        });
        
        if(dirMode)
            fileField.setToolTipText("Path to a directory");
        else
            fileField.setToolTipText("Path to a single file");
            
        fileChooserButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent arg0) {

                try {
                    if (dirMode)
                        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                    else
                        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

                    int returnVal = chooser.showOpenDialog(root);
                    if (returnVal == JFileChooser.APPROVE_OPTION) {
                        fileField.setText(chooser.getSelectedFile().getAbsolutePath());
                    }
                } catch (Exception e) {
                      // Do not do anything here
                }
            }

        });
        fileChooserButton.setToolTipText("Open file chooser");
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridy = 1; 
        gbc.gridx = GridBagConstraints.RELATIVE;
        gbc.gridwidth = 2;
        gbc.gridheight = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.weightx = 1;
        gbc.insets = new Insets(7,0,7,7);
        
        add(fileField, gbc);
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        gbc.insets = new Insets(7,0,7,0);
        add(fileChooserButton, gbc);

    }

    public void setEnabled(boolean arg0) {
        fileField.setEnabled(arg0);
        fileChooserButton.setEnabled(arg0);
    }

    public JFileChooser getFileChooser() {
        return chooser;
    }

    public JTextField getTextField() {
        return fileField;
    }

}
/**
 * A label combined with a radio button.
 * 
 * @author Michael Wurst
 * @version $Id: WVToolConfigurationWizard.java,v 1.2 2007/06/07 17:12:36 ingomierswa Exp $
 *
 */
class LabelRadioButton extends JPanel {

    private static final long serialVersionUID = -2638428600554148347L;

    private final JRadioButton button;

    public LabelRadioButton(String label) {

        super(new FlowLayout(FlowLayout.LEADING));

        button = new JRadioButton();
        button.setToolTipText(label);
        this.add(button);
        this.add(new JLabel(label));
    }

    public JRadioButton getButton() {

        return button;
    }

}
