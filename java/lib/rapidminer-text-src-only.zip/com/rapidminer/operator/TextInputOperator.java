package com.rapidminer.operator;

/*
 *  YALE - Yet Another Learning Environment
 *
 *  Copyright (C) 2001-2006 by the class authors
 *
 *  Project administrator: Ingo Mierswa
 *  Plugin administrator: Michael Wurst 
 *
 *      YALE was mainly written by (former) members of the
 *      Artificial Intelligence Unit
 *      Computer Science Department
 *      University of Dortmund
 *      44221 Dortmund,  Germany
 *
 *  Complete list of YALE developers available at our web site:
 *
 *       http://yale.sf.net
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */

import java.io.File;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.rapidminer.Process;
import com.rapidminer.example.Attribute;
import com.rapidminer.example.Example;
import com.rapidminer.example.ExampleSet;
import com.rapidminer.example.table.AttributeFactory;
import com.rapidminer.parameter.ParameterType;
import com.rapidminer.parameter.ParameterTypeDirectory;
import com.rapidminer.parameter.ParameterTypeList;
import com.rapidminer.parameter.UndefinedParameterError;
import com.rapidminer.tools.Ontology;

import edu.udo.cs.wvtool.config.WVTConfiguration;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.main.WVTFileInputList;
import edu.udo.cs.wvtool.main.WVTInputList;


/**
 * This operator wraps the Word Vector Tool by Michael Wurst, creating an {@link ExampleSet} from a collection of texts. The output example set will contain one row for each text and one column for each word (or for each word stem). The text collection must be specified in one of two ways.
 * <ul>
 * <li>If the parameter list <var>texts</var> is specified, each key-value pair must contain the class (e.g. &quot;positive&quot;, &quot;negative&quot;, &quot;interesting&quot; etc.) and the value must be a directory which holds the texts of this class.</li>
 * <li>Otherwise the operator expects an {@link ExampleSet} in its input. Up to four regular attributes of this example set having special names and the label are evaluated:
 * <dl>
 * <dt>&quot;document_source&quot;</dt>
 * <dd>A file, directory, or URL specifying a (set of) text(s)</dd>
 * <dt>&quot;type&quot;</dt>
 * <dd>The document type, e.g. xml or pdf</dd>
 * <dt>&quot;encoding&quot;</dt>
 * <dd>The content encoding</dd>
 * <dt>&quot;language&quot;</dt>
 * <dd>The content language</dd>
 * <dt>The label attribute</dt>
 * <dd>The class of the text(s)</dd>
 * </dl>
 * </li>
 * </ul>
 * 
 * A note on encoding: the encoding can be set manually. If not set manually, the default encoding is used or, for XML files,
 * the encoding that is specified in the header of the XML file. The encoding of HTML and text files is not detected automatically.
 * 
 * A note on PDF processing: Converting PDF to text is non-trivial. This operator uses the PDFBox library to achieve this and
 * the quality and the ability to decode PDF is limited by the ability of PDFBox to achieve this. 
 * 
 * A note on XML and HTML processing: For vector creation on HTML and XML documents, all tags are ignored and only texts between tags is
 * used. 
 * 
 * @author Ingo Mierswa, Simon Fischer, Michael Wurst
 * @version $Id: TextInputOperator.java,v 1.1 2007/07/27 22:46:05 ingomierswa Exp $
 */
public class TextInputOperator extends TextInput {

    private com.rapidminer.example.Attribute label = null;

    public TextInputOperator(OperatorDescription description) {
        super(description);
    }

    protected com.rapidminer.example.Attribute getLabel() throws OperatorException {
        return this.label;
    }

    protected WVTConfiguration createConfiguration() throws OperatorException {
        
        return new WVTConfiguration();
    }

    protected WVTInputList createInputList() throws OperatorException {
        WVTInputList list = null;
        List textList = getParameterList("texts");
        label = null;
        if (textList.size() == 0) {
            ExampleSet exampleSet = getInput(ExampleSet.class);
            label = exampleSet.getAttributes().getLabel();
            list = createInputList(exampleSet);
        } else {
            label = AttributeFactory.createAttribute("label", Ontology.NOMINAL);
            list = createInputList(textList, label);
        }
        return list;
    }

    private WVTInputList createInputList(ExampleSet exampleSet) throws OperatorException {
        log("Creating WVTool input list from input example set.");

        Attribute documentClassAtt = exampleSet.getAttributes().getLabel();
        if ((documentClassAtt != null) && !documentClassAtt.isNominal())
            throw new UserError(this, 101, new Object[] { "wvtool", documentClassAtt });
        Attribute sourceNameAtt = exampleSet.getAttributes().get("document_source");
        if (sourceNameAtt == null)
            throw new UserError(this, 111, "document_source");
        Attribute contentTypeAtt = exampleSet.getAttributes().get("type");
        Attribute contentEncodingAtt = exampleSet.getAttributes().get("encoding");
        Attribute contentLanguageAtt = exampleSet.getAttributes().get("language");

        String defaultContentType = getParameterAsString("default_content_type");
        String defaultContentEncoding = getParameterAsString("default_content_encoding");
        String defaultContentLanguage = getParameterAsString("default_content_language");

        WVTFileInputList list = new WVTFileInputList(documentClassAtt.getMapping().size());

        Iterator<Example> r = exampleSet.iterator();
        while (r.hasNext()) {
            Example e = r.next();
            String contentType = (contentTypeAtt != null) ? e.getValueAsString(contentTypeAtt) : defaultContentType;
            String contentEncoding = (contentEncodingAtt != null) ? e.getValueAsString(contentEncodingAtt)
                    : defaultContentEncoding;
            String contentLanguage = (contentLanguageAtt != null) ? e.getValueAsString(contentLanguageAtt)
                    : defaultContentLanguage;
            if (documentClassAtt != null) {
                list.addEntry(new WVTDocumentInfo(resolveFilename(e.getValueAsString(sourceNameAtt)), contentType,
                        contentEncoding, contentLanguage, (int) e.getValue(documentClassAtt)));
            } else {
                list.addEntry(new WVTDocumentInfo(resolveFilename(e.getValueAsString(sourceNameAtt)), contentType,
                        contentEncoding, contentLanguage));
            }
        }
        return list;
    }

    private WVTInputList createInputList(List textList, Attribute label_) throws UndefinedParameterError {
        log("Creating WVTool input list from parameter list (ignoring input example set if any).");

        String contentType = getParameterAsString("default_content_type");
        String contentEncoding = getParameterAsString("default_content_encoding");
        String contentLanguage = getParameterAsString("default_content_language");

        Iterator i = textList.iterator();
        while (i.hasNext()) {
            Object[] keyValue = (Object[]) i.next();
            label_.getMapping().mapString((String) keyValue[0]);
        }
        WVTFileInputList list = new WVTFileInputList(label_.getMapping().getValues().size());
        i = textList.iterator();
        while (i.hasNext()) {
            Object[] keyValue = (Object[]) i.next();
            list.addEntry(new WVTDocumentInfo(resolveFilename((String) keyValue[1]), contentType, contentEncoding,
                    contentLanguage, label_.getMapping().mapString((String) keyValue[0])));
        }
        return list;
    }

    protected String resolveFilename(String name) {

        Process associatedExperiment = getProcess();

        if (associatedExperiment != null)
            return associatedExperiment.resolveFileName(name).getAbsolutePath();
        else
            return new File(name).getAbsolutePath();
    }
    
    public List<ParameterType> getParameterTypes() {

        ParameterType textListParam = new ParameterTypeList("texts", "Specifies a list of class/directory pairs.",
                new ParameterTypeDirectory("directory_name",
                        "All files in this directory will be associated with the class specified by the key.", false));
        textListParam.setExpert(false);
        
        
        List<ParameterType> types = new LinkedList<ParameterType>();
        
        types.add(textListParam);
        types.addAll(super.getParameterTypes());
        return types;
    }
}
