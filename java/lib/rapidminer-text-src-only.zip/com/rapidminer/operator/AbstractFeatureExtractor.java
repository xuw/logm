/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator;

import java.io.File;
import java.util.Iterator;
import java.util.List;

import com.rapidminer.Process;
import com.rapidminer.example.Attribute;
import com.rapidminer.example.ExampleSet;
import com.rapidminer.operator.extraction.AttributeQueryMap;
import com.rapidminer.operator.extraction.DefaultFeatureExtractor;
import com.rapidminer.operator.extraction.ExtractionException;
import com.rapidminer.operator.extraction.FeatureExtractor;
import com.rapidminer.operator.extraction.util.ConcatanatedFeatureExtractor;
import com.rapidminer.operator.extraction.util.FeatureExtractionUtil;
import com.rapidminer.parameter.ParameterType;
import com.rapidminer.parameter.ParameterTypeBoolean;
import com.rapidminer.parameter.ParameterTypeCategory;
import com.rapidminer.parameter.ParameterTypeString;

import edu.udo.cs.wvtool.config.WVTConfiguration;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.main.WVTInputList;
import edu.udo.cs.wvtool.main.WVTWordVector;
import edu.udo.cs.wvtool.util.WVToolLogger;
import edu.udo.cs.wvtool.wordlist.WVTWordList;

/**
 * This is the abstract superclass for all word vector creation operators.
 * 
 * @author Michael Wurst, Ingo Mierswa
 * @version $Id$
 */
public abstract class AbstractFeatureExtractor extends Operator {

    public static final String ID_ATTRIBUTE_TYPE = "id_attribute_type";

    private WVTConfiguration config = new WVTConfiguration();
    
    public AbstractFeatureExtractor(OperatorDescription description) {
        super(description);
    }

    /** link to the experiment that is used, in case this operator is not part of an experiment */
    private Process externalExperiment = null;
    

    /**
     * @return Returns the external experiment
     */
    public Process getExternalExperiment() {
        return externalExperiment;
    }

    /**
     * @param process Set an external experiment, if the main experiment cannot be resolved
     */
    public void setExternalExperiment(Process process) {
        this.externalExperiment = process;
    }
    
    
    protected abstract WVTInputList createInputList() throws OperatorException;

    protected abstract Attribute getLabel() throws OperatorException;

    public Class[] getInputClasses() {
        return new Class[0];
    }

    public Class[] getOutputClasses() {
        return new Class[] { ExampleSet.class };
    }

    // ================================================================================

    public Process getProcess() {
       
        Process associatedExperiment = super.getProcess();
        if(associatedExperiment == null)
            associatedExperiment = this.externalExperiment;
        
        return associatedExperiment;
    }

    protected String resolveFilename(String name) {

        	Process associatedExperiment = getProcess();
    
        	if (associatedExperiment != null)
        		return associatedExperiment.resolveFileName(name).getAbsolutePath();
        	else
        		return new File(name).getAbsolutePath();
    }


    public IOObject[] apply() throws OperatorException {
        WVToolLogger.setGlobalLogger(new WVToolRapidMinerLogger(this));
        WVTInputList list = createInputList();

        String featureExtractorClassName = null;
            FeatureExtractor extractorExt = null;

            if ((featureExtractorClassName != null) && (featureExtractorClassName.length()) > 0) {

                Class c = null;
                try {
                    c = Class.forName(featureExtractorClassName);
                    extractorExt = (FeatureExtractor) c.newInstance();
                } catch (Throwable t) {
                    extractorExt = null;
                    logWarning("Could not initialize the extractor. Ignoring it.");
                }
            }

            WVTWordList wordList = new WVTWordList(0);
            
            FeatureExtractor features = null;    
            
            AttributeQueryMap aqMap = null;
            try {
                aqMap = FeatureExtractionUtil.getAttributeQueryMap(getParameters());
            } catch (ExtractionException e3) {
                UserError error = e3.getUserError();
                error.setOperator(this);
                throw error;
            }

            if(aqMap.getAttributes().size() > 0)
                features = new DefaultFeatureExtractor(aqMap, config);
            
            FeatureExtractor combinedExtractor = null;
            
            if((extractorExt != null)&&(features != null)) {
                combinedExtractor = new ConcatanatedFeatureExtractor(new FeatureExtractor[]{extractorExt, features});
            } else {
                if(extractorExt != null)
                    combinedExtractor = extractorExt;
                else
                    if(features != null)
                        combinedExtractor = features;
            } 
            
            ExampleTableOutputFilter out = new ExampleTableOutputFilter(getLabel(), wordList,
                    getParameterAsBoolean("use_content_attributes"), getParameterAsInt(ID_ATTRIBUTE_TYPE), combinedExtractor, this);


            Iterator it = list.getEntries();
            while(it.hasNext()) {
                
                WVTDocumentInfo docInfo = (WVTDocumentInfo) it.next();
                WVTWordVector vector = new WVTWordVector();
                vector.setDocumentInfo(docInfo);
                vector.setValues(new double[0]);
                out.write(vector);    
            }
            
            return new IOObject[] { out.createExampleSet() };

    }

    // ================================================================================

    public List<ParameterType> getParameterTypes() {
        List<ParameterType> types = super.getParameterTypes();
        types.add(new ParameterTypeString("default_content_type",
                "The default content type if not specified by the example set (possible values: pdf, html, htm, xml, text, txt).", ""));
        types.add(new ParameterTypeString("default_content_encoding",
                "The default content encoding if not specified by the example set (only encodings supported by Java can be used).", ""));
        types.add(new ParameterTypeString("default_content_language",
                "The default content language if not specified by the example set.", ""));

        types
                .add(new ParameterTypeBoolean(
                        "use_content_attributes",
                        "If set to true, the returned example set will contain content type, encoding, and language attributes.",
                        false));
        
        types
                .add(new ParameterTypeCategory(
                        ID_ATTRIBUTE_TYPE,
                        "Indicates if long ids (complete paths), short ids (last part of the source name), or numerical ids will be used.",
                        ExampleTableOutputFilter.ID_TYPE_NAMES, ExampleTableOutputFilter.ID_TYPE_NUMERICAL));

        ParameterType featuresType = FeatureExtractionUtil.createQueryParameter();
        featuresType.setExpert(true);
        types.add(featuresType);
        
        ParameterType param = FeatureExtractionUtil.createNamespaceParameter();
        types.add(param);
                
        return types;
    }
}
