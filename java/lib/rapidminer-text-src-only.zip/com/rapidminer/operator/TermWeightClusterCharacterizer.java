/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator;

import java.util.Iterator;
import java.util.List;

import com.rapidminer.example.Attribute;
import com.rapidminer.example.Example;
import com.rapidminer.example.ExampleSet;
import com.rapidminer.operator.learner.clustering.Cluster;
import com.rapidminer.operator.learner.clustering.ClusterIterator;
import com.rapidminer.operator.learner.clustering.ClusterModel;
import com.rapidminer.operator.learner.clustering.ClusterNode;
import com.rapidminer.operator.learner.clustering.IdUtils;
import com.rapidminer.operator.learner.clustering.MutableCluster;
import com.rapidminer.parameter.ParameterType;
import com.rapidminer.parameter.ParameterTypeInt;

/**
 * Operator that calculates characteristic terms for each cluster of a 
 * cluster model by adding up feature values in each cluster and then
 * selecting the features with the highest sum value.
 * 
 * @author Michael Wurst, Ingo Mierswa
 * @version $Id: TermWeightClusterCharacterizer.java,v 1.2 2007/07/19 13:49:05 mjwurst Exp $
 */
public class TermWeightClusterCharacterizer extends Operator {

    public TermWeightClusterCharacterizer(OperatorDescription description) {
        super(description);
    }

    public InputDescription getInputDescription(Class cls) {
        if (ExampleSet.class.isAssignableFrom(cls)) {
            return new InputDescription(cls, true, false);
        } 
        if (ClusterModel.class.isAssignableFrom(cls))
            return new InputDescription(cls, true, false);
        else {
            return super.getInputDescription(cls);
        }
    }
    
    public IOObject[] apply() throws OperatorException {
        ExampleSet es = getInput(ExampleSet.class);
        ClusterModel cm = getInput(ClusterModel.class);
        
        ClusterIterator ci = new ClusterIterator(cm);
        
        while(ci.hasMoreClusters()) {
            Cluster cl = ci.next();
            Iterator<String> docIt = null;
            if(cl instanceof ClusterNode)
                docIt = ((ClusterNode) cl).getObjectsInSubtree();
            else
                docIt = cl.getObjects();
        
            double[] weightSum = new double[es.getAttributes().size()];
            
            while(docIt.hasNext()) {
                Example e = IdUtils.getExampleFromId(es, docIt.next());
                int index = 0;
                for (Attribute att : es.getAttributes()) {
                    weightSum[index++] += e.getValue(att);
                }
            }
            
            int[] highest = getHighest(weightSum, getParameterAsInt("k"));
            Attribute[] allAttributes = es.getAttributes().createRegularAttributeArray();
            StringBuffer labelBuffer = new StringBuffer();
            labelBuffer.append(allAttributes[highest[0]].getName());
            for(int i = 1; i < highest.length; i++) {
                labelBuffer.append(" "); labelBuffer.append(allAttributes[highest[i]].getName()); 
            }
            
            ((MutableCluster) cl).setDescription(labelBuffer.toString());   
        }  
        return new IOObject[0];
    }

    public int[] getHighest(double[] values, int k) {
        if(values.length < k)
            k = values.length;
        
        int[] result = new int[k];
        double[] vals = new double[values.length];
        for(int i = 0; i < values.length; i++)
            vals[i] = values[i];
        
        for(int j = 0; j < result.length; j++) {
            double maxValue = Double.NEGATIVE_INFINITY;
            int maxIndex = 0;
            
            for(int i = 0; i < vals.length; i++) {
                if(vals[i] > maxValue) {
                    maxValue = vals[i];
                    maxIndex = i;
                }
            }
            vals[maxIndex] = Double.NEGATIVE_INFINITY;
            result[j] = maxIndex;
        }
        return result;
    }
    
    public Class[] getInputClasses() {
        return new Class[]{ExampleSet.class, ClusterModel.class};
    }

    public Class[] getOutputClasses() {
        return new Class[0];
    }
    
    public List<ParameterType> getParameterTypes() {
        List<ParameterType> types = super.getParameterTypes();
        
        ParameterType type = new ParameterTypeInt("k", "the maximal number of keywords", 1, Integer.MAX_VALUE, 3);
        type.setExpert(false);
        types.add(type);

        return types;
    }
}
