package com.rapidminer.operator.wordfilter;

import com.rapidminer.operator.AbstractTokenProcessor;
import com.rapidminer.operator.OperatorDescription;

import edu.udo.cs.wvtool.generic.wordfilter.StopWordsWrapper;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.util.TokenEnumeration;
import edu.udo.cs.wvtool.util.WVToolException;

/**
 * A standard english stopword list.
 * 
 * @author Michael Wurst
 * @version $Id$
 * 
 */
public class EnglishStopwordFilter extends AbstractTokenProcessor {

    private StopWordsWrapper filter = new StopWordsWrapper(0);

    public EnglishStopwordFilter(OperatorDescription description) {
        super(description);
    }

    protected TokenEnumeration process(TokenEnumeration tokens, WVTDocumentInfo docInfo) throws WVToolException {

        return filter.filter(tokens, docInfo);
    }

}
