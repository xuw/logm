package com.rapidminer.operator.wordfilter;

import java.util.LinkedList;
import java.util.List;

import com.rapidminer.operator.AbstractTokenProcessor;
import com.rapidminer.operator.IOObject;
import com.rapidminer.operator.OperatorDescription;
import com.rapidminer.operator.OperatorException;
import com.rapidminer.parameter.ParameterType;
import com.rapidminer.parameter.ParameterTypeInt;

import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.util.TokenEnumeration;
import edu.udo.cs.wvtool.util.TokenEnumerationAdapter;
import edu.udo.cs.wvtool.util.WVToolException;

/**
 * Filter tokens based on their length (the number of characters they contain).
 * 
 * @author Michael Wurst
 * @version $Id$
 * 
 */
public class TokenLengthFilter extends AbstractTokenProcessor {

    private int minNumberOfChars = 0;

    public TokenLengthFilter(OperatorDescription description) {
        super(description);
    }

    protected TokenEnumeration process(TokenEnumeration tokens, WVTDocumentInfo docInfo) throws WVToolException {

        List<String> outputTokens = new LinkedList<String>();
        while (tokens.hasMoreTokens()) {

            String token = tokens.nextToken();

            if (token.length() >= minNumberOfChars)
                outputTokens.add(token);
        }

        return new TokenEnumerationAdapter(outputTokens);

    }

    public IOObject[] apply() throws OperatorException {

        minNumberOfChars = getParameterAsInt("min_chars");
        return super.apply();
    }

    public List<ParameterType> getParameterTypes() {

        List<ParameterType> types = super.getParameterTypes();

        types.add(new ParameterTypeInt("min_chars", "The minimal number of characters that a token must contain to be considered.", 0, (int) Double.POSITIVE_INFINITY, 4));
        return types;
    }

}
