/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import com.rapidminer.Process;
import com.rapidminer.example.Attribute;
import com.rapidminer.example.AttributeWeights;
import com.rapidminer.example.ExampleSet;
import com.rapidminer.operator.extraction.AttributeQueryMap;
import com.rapidminer.operator.extraction.DefaultFeatureExtractor;
import com.rapidminer.operator.extraction.ExtractingInputFilter;
import com.rapidminer.operator.extraction.ExtractionException;
import com.rapidminer.operator.extraction.FeatureExtractor;
import com.rapidminer.operator.extraction.TextExtractor;
import com.rapidminer.operator.extraction.util.ConcatanatedFeatureExtractor;
import com.rapidminer.operator.extraction.util.FeatureExtractionUtil;
import com.rapidminer.parameter.ParameterType;
import com.rapidminer.parameter.ParameterTypeBoolean;
import com.rapidminer.parameter.ParameterTypeCategory;
import com.rapidminer.parameter.ParameterTypeFile;
import com.rapidminer.parameter.ParameterTypeInt;
import com.rapidminer.parameter.ParameterTypeString;
import com.rapidminer.parameter.ParameterTypeStringCategory;
import com.rapidminer.parameter.UndefinedParameterError;
import com.rapidminer.tools.ObjectVisualizerService;

import edu.udo.cs.wvtool.config.WVTConfiguration;
import edu.udo.cs.wvtool.config.WVTConfigurationFact;
import edu.udo.cs.wvtool.generic.tokenizer.NGramTokenizer;
import edu.udo.cs.wvtool.generic.tokenizer.WVTTokenizer;
import edu.udo.cs.wvtool.generic.wordfilter.AbstractStopWordFilter;
import edu.udo.cs.wvtool.generic.wordfilter.CombinedWordFilter;
import edu.udo.cs.wvtool.generic.wordfilter.StopWordFilterFile;
import edu.udo.cs.wvtool.generic.wordfilter.WVTWordFilter;
import edu.udo.cs.wvtool.main.WVTInputList;
import edu.udo.cs.wvtool.main.WVTool;
import edu.udo.cs.wvtool.util.WVToolException;
import edu.udo.cs.wvtool.util.WVToolLogger;
import edu.udo.cs.wvtool.wordlist.WVTWordList;

/**
 * This is the abstract superclass for all word vector creation operators.
 * 
 * @author Ingo Mierswa, Michael Wurst
 * @version $Id: AbstractWVToolOperator.java,v 1.3 2007/07/19 13:49:05 mjwurst Exp $
 */
public abstract class AbstractWVToolOperator extends Operator {

    public static final String ID_ATTRIBUTE_TYPE = "id_attribute_type";

    public static String[] STEPS = { WVTConfiguration.STEP_LOADER, WVTConfiguration.STEP_INPUT_FILTER,
            WVTConfiguration.STEP_CHAR_MAPPER, WVTConfiguration.STEP_TOKENIZER, WVTConfiguration.STEP_WORDFILTER,
            WVTConfiguration.STEP_STEMMER, WVTConfiguration.STEP_VECTOR_CREATION };

    public static Class<?>[] STEP_INTERFACES = { edu.udo.cs.wvtool.generic.loader.WVTDocumentLoader.class,
            edu.udo.cs.wvtool.generic.inputfilter.WVTInputFilter.class,
            edu.udo.cs.wvtool.generic.charmapper.WVTCharConverter.class,
            edu.udo.cs.wvtool.generic.tokenizer.WVTTokenizer.class,
            edu.udo.cs.wvtool.generic.wordfilter.WVTWordFilter.class,
            edu.udo.cs.wvtool.generic.stemmer.WVTStemmer.class,
            edu.udo.cs.wvtool.generic.vectorcreation.WVTVectorCreator.class };

    public static final Class<?>[] SUPPORTED_IMPLEMENTATIONS = {
            edu.udo.cs.wvtool.generic.loader.UniversalLoader.class,
            edu.udo.cs.wvtool.generic.inputfilter.TextInputFilter.class,
            edu.udo.cs.wvtool.generic.inputfilter.XMLInputFilter.class,
            edu.udo.cs.wvtool.generic.inputfilter.PDFInputFilter.class,
            edu.udo.cs.wvtool.generic.inputfilter.SimpleTagIgnoringReader.class,
            edu.udo.cs.wvtool.generic.inputfilter.SelectingInputFilter.class,
            edu.udo.cs.wvtool.generic.charmapper.DummyCharConverter.class,
            edu.udo.cs.wvtool.generic.tokenizer.SimpleTokenizer.class,
            edu.udo.cs.wvtool.generic.wordfilter.SelectingWordFilter.class,
            edu.udo.cs.wvtool.generic.wordfilter.StopWordsWrapperGerman.class,
            edu.udo.cs.wvtool.generic.wordfilter.DummyWordFilter.class,
            edu.udo.cs.wvtool.generic.wordfilter.StopWordsWrapper.class,
            edu.udo.cs.wvtool.external.StopwordsFrench.class,
            edu.udo.cs.wvtool.generic.stemmer.DummyStemmer.class,
            edu.udo.cs.wvtool.generic.stemmer.FastGermanStemmer.class,
            edu.udo.cs.wvtool.generic.stemmer.PorterStemmerWrapper.class,
            edu.udo.cs.wvtool.generic.stemmer.SnowballStemmerWrapper.class,
            edu.udo.cs.wvtool.generic.stemmer.ToLowerCaseConverter.class,
            // edu.udo.cs.wvtool.generic.stemmer.WordNetHypernymStemmer.class,
            // edu.udo.cs.wvtool.generic.stemmer.WordNetSynonymStemmer.class,
            edu.udo.cs.wvtool.generic.stemmer.LovinsStemmerWrapper.class,
            edu.udo.cs.wvtool.generic.vectorcreation.TermFrequency.class,
            edu.udo.cs.wvtool.generic.vectorcreation.TermOccurrences.class,
            edu.udo.cs.wvtool.generic.vectorcreation.TFIDF.class,
            edu.udo.cs.wvtool.generic.vectorcreation.BinaryOccurrences.class, };

    public static final Class<?>[] DEFAULT_IMPLEMENTATIONS = { edu.udo.cs.wvtool.generic.loader.UniversalLoader.class,
            edu.udo.cs.wvtool.generic.inputfilter.SelectingInputFilter.class,
            edu.udo.cs.wvtool.generic.charmapper.DummyCharConverter.class,
            edu.udo.cs.wvtool.generic.tokenizer.SimpleTokenizer.class,
            edu.udo.cs.wvtool.generic.wordfilter.StopWordsWrapper.class,
            edu.udo.cs.wvtool.generic.stemmer.LovinsStemmerWrapper.class,
            edu.udo.cs.wvtool.generic.vectorcreation.TFIDF.class };

    public static final String[][] KNOWN_IMPLEMENTATIONS = new String[STEP_INTERFACES.length][];

    private ClassNameMapper[] IMPLEMENTATION_MAPS;

    static {
        for (int i = 0; i < STEP_INTERFACES.length; i++) {
            Collection<String> implementations = new HashSet<String>();

            for (int j = 0; j < SUPPORTED_IMPLEMENTATIONS.length; j++)
                if (STEP_INTERFACES[i].isAssignableFrom(SUPPORTED_IMPLEMENTATIONS[j]))
                    implementations.add(SUPPORTED_IMPLEMENTATIONS[j].getCanonicalName());

            // if (STEP_INTERFACES[i].getClassLoader() instanceof URLClassLoader) {
            // URLClassLoader loader = (URLClassLoader) STEP_INTERFACES[i].getClassLoader();
            //
            // URL[] urls = loader.getURLs();
            // for (int j = 0; j < urls.length; j++) {
            // if (urls[j].getProtocol().equals("file")) {
            // File file = new File(urls[j].getFile());
            // if (file.isFile() && file.getName().endsWith(".jar")) {
            // try {
            // List<String> implementationsInJar = new LinkedList<String>();
            // Tools.findImplementationsInJar(loader, new JarFile(file), STEP_INTERFACES[i],
            // implementationsInJar);
            // implementations.addAll(implementationsInJar);
            // } catch (Throwable t) {
            // t.printStackTrace();
            // }
            // }
            // }
            // }
            // }

            KNOWN_IMPLEMENTATIONS[i] = new String[implementations.size()];
            implementations.toArray(KNOWN_IMPLEMENTATIONS[i]);
        }
    }

    // ================================================================================

    public AbstractWVToolOperator(OperatorDescription description) {
        super(description);
    }

    /** link to the experiment that is used, in case this operator is not part of an experiment */
    private Process externalExperiment = null;
    

    /**
     * @return Returns the external experiment
     */
    public Process getExternalExperiment() {
        return externalExperiment;
    }

    /**
     * @param process Set an external experiment, if the main experiment cannot be resolved
     */
    public void setExternalExperiment(Process process) {
        this.externalExperiment = process;
    }
    
    
    protected abstract WVTInputList createInputList() throws OperatorException;

    protected abstract Attribute getLabel() throws OperatorException;

    public Class[] getInputClasses() {
        return new Class[0];
    }

    public Class[] getOutputClasses() {
        return new Class[] { ExampleSet.class };
    }

    // ================================================================================

    protected WVTConfiguration createConfiguration() throws OperatorException {
        log("Creating WVTool configuration.");

        if (isParameterSet("wvt_configuration")) {
            String configClass = getParameterAsString("wvt_configuration");
            log("Using WVTConfiguration '" + configClass + "'");
            Class c = null;
            try {
                c = com.rapidminer.tools.Tools.classForName(configClass);
            } catch (Throwable t) {
                throw new UserError(this, t, 904, new Object[] { configClass, t });
            }
            if (WVTConfiguration.class.isAssignableFrom(c)) {
                try {
                    return (WVTConfiguration) c.newInstance();
                } catch (Throwable t) {
                    throw new UserError(this, t, 904, new Object[] { configClass, t });
                }
            } else {
                throw new UserError(this, 914, new Object[] { configClass, WVTConfiguration.class });
            }
        } else {
            WVTConfiguration config = new WVTConfiguration();
            log("Using simple WVTConfiguration.");
            for (int i = 0; i < STEPS.length; i++) {
                String implementation = getParameterAsString(STEPS[i]);
                if ((implementation != null) && (implementation.trim().length() > 0)) {
                    Object implementationObj = null;
                    try {
                        implementationObj = IMPLEMENTATION_MAPS[i].getInstantiation(implementation);
                        if (!STEP_INTERFACES[i].isInstance(implementationObj))
                            throw new WVToolException("Class given for " + STEPS[i]
                                    + " does not match the required interface " + STEP_INTERFACES[i].toString());
                    } catch (Exception e) {
                        WVToolLogger.getGlobalLogger().logException(
                                "Could not initialize the implementation for step " + STEPS[i], e);
                        implementationObj = null;
                    }
                    config.setConfigurationRule(STEPS[i], new WVTConfigurationFact(implementationObj));
                }
            }
            int minChars = getParameterAsInt("min_chars");
            int ngrams = getParameterAsInt("ngrams");

            WVTWordFilter filter = null;
            try {
                filter = (WVTWordFilter) IMPLEMENTATION_MAPS[4]
                        .getInstantiation(getParameterAsString(WVTConfiguration.STEP_WORDFILTER));
            } catch (Exception e) {
                WVToolLogger.getGlobalLogger().logException("Could not initialize the word filter", e);
                filter = null;
            }

            if (filter instanceof AbstractStopWordFilter) {
                if ((minChars > ngrams) && (ngrams > 0)) {
                    logWarning("Minimal number of characters is greater than the length of the ngrams. This parameter will be ignored.");
                    minChars = ngrams;
                }

                if(isParameterSet("add_stopwords")) {
                    try {
                        filter = new CombinedWordFilter(minChars, new AbstractStopWordFilter[]{
                                new StopWordFilterFile(minChars, new FileReader(getParameterAsFile("add_stopwords"))),
                                (AbstractStopWordFilter) filter});
                    } catch (UndefinedParameterError e) {
                        // Cannot happen
                    } catch (FileNotFoundException e) {
                        logError("File not found : " + getParameterAsFile("add_stopwords") + ": " + e.getMessage());
                    } catch (IOException e) {
                        logError("File not be read : " + getParameterAsFile("add_stopwords") + ": " + e.getMessage());
                    }   
                }                
                ((AbstractStopWordFilter) filter).setMinNumChars(minChars);
                config.setConfigurationRule(WVTConfiguration.STEP_WORDFILTER, new WVTConfigurationFact(filter));
            } else {
                logWarning("Could not apply the min_chars parameter as the word filter is not of type AbstractStopWordFilter");
            }
            
            if (ngrams > 0) {
                WVTTokenizer innerTokenizer = null;

                try {
                    innerTokenizer = (WVTTokenizer) IMPLEMENTATION_MAPS[3]
                            .getInstantiation(getParameterAsString(WVTConfiguration.STEP_TOKENIZER));
                } catch (Exception e) {
                    WVToolLogger.getGlobalLogger().logException("Could not initialize the tokenizer", e);
                    innerTokenizer = null;
                }

                WVTTokenizer tokenizer = new NGramTokenizer(ngrams, innerTokenizer);
                config.setConfigurationRule(WVTConfiguration.STEP_TOKENIZER, new WVTConfigurationFact(tokenizer));
            }
            
            String textExtractorStr = getParameterAsString("text_query");
            if(textExtractorStr != null) {
                
                TextExtractor textExtractor = null;
                try {
                    textExtractor = FeatureExtractionUtil.getExtractor(textExtractorStr, FeatureExtractionUtil.getNamespaceMapping(getParameters()));
                } catch (ExtractionException e) {
                    
                    UserError error = e.getUserError();
                    error.setOperator(this);
                    throw error;

                }

                ExtractingInputFilter extrInFilter = new ExtractingInputFilter(config,textExtractor);
                config.setConfigurationRule(WVTConfiguration.STEP_INPUT_FILTER, new WVTConfigurationFact(extrInFilter));
            }
            return config;
        }
 
    }

    @Override
    public Process getProcess() {
       
        Process associatedExperiment = super.getProcess();
        if(associatedExperiment == null)
            associatedExperiment = this.externalExperiment;
        
        return associatedExperiment;
    }

    protected String resolveFilename(String name) {

        	Process associatedExperiment = getProcess();
    
        	if (associatedExperiment != null)
        		return associatedExperiment.resolveFileName(name).getAbsolutePath();
        	else
        		return new File(name).getAbsolutePath();
    }

    private void pruneWordList(WVTWordList wordList) throws UndefinedParameterError {
        // Prune the word list
        String pruneBelowStr = (String) getParameter("prune_below");
        String pruneAboveStr = (String) getParameter("prune_above");
        int pruneBelow = -1;
        int pruneAbove = -1;

        try {
            if (pruneBelowStr.charAt(pruneBelowStr.length() - 1) == '%') {

                pruneBelowStr = pruneBelowStr.substring(0, pruneBelowStr.length() - 1);
                double rankFraction = 1.0 - (Double.parseDouble(pruneBelowStr) / 100.0);
                pruneBelow = wordList.getFrequencyByRank((int) Math.max(wordList.getNumWords() * rankFraction, 1));

            } else {
                pruneBelow = Integer.parseInt(pruneBelowStr);
            }
        } catch (NumberFormatException e) {
            logError("Could not parse the parameter prune_below: " + e.getMessage());
        }

        try {
            if (pruneAboveStr.charAt(pruneAboveStr.length() - 1) == '%') {

                pruneAboveStr = pruneAboveStr.substring(0, pruneAboveStr.length() - 1);
                double rankFraction = Double.parseDouble(pruneAboveStr) / 100.0;
                pruneAbove = wordList.getFrequencyByRank((int) Math.max(wordList.getNumWords() * rankFraction, 1));
            } else {
                pruneAbove = Integer.parseInt(pruneAboveStr);
            }
        } catch (NumberFormatException e) {
            logError("Could not parse the parameter prune_above: " + e.getMessage());
        }

        if ((pruneBelow >= 0) || (pruneAbove >= 0)) {
            log("Pruning word list.");
            wordList.pruneByFrequency(pruneBelow < 0 ? 0 : pruneBelow, pruneAbove < 0 ? Integer.MAX_VALUE : pruneAbove);
        }
    }

    // ================================================================================

    public IOObject[] apply() throws OperatorException {
        WVToolLogger.setGlobalLogger(new WVToolRapidMinerLogger(this));
        WVTInputList list = createInputList();
        try {
            WVTool wvt = new WVTool(false);
            WVTConfiguration config = createConfiguration();

            boolean userWordListMode = true;
            AttributeWeights weights = null;

            try {
                weights = getInput(AttributeWeights.class);
            } catch (Exception e) {
                userWordListMode = false;
                weights = null;
            }

            WVTWordList wordList = null;
            if (isParameterSet("input_word_list")) {
                if (userWordListMode) {
                    logWarning("Input attribute weights are ignored for word list loaded from file.");
                }
                File wordListFile = getParameterAsFile("input_word_list");
                try {
                    Reader wordListIn = new BufferedReader(new FileReader(wordListFile));
                    wordList = new WVTWordList(wordListIn);
                } catch (IOException e) {
                    throw new UserError(this, 302, wordListFile, e.getMessage());
                }
            } else {
                if (userWordListMode) {

                    LinkedList<String> userWordList = new LinkedList<String>();
                    List<String> attributeNames = new LinkedList<String>(weights.getAttributeNames());

                    for (int j = 0; j < attributeNames.size(); j++) {
                        String attributeName = attributeNames.get(j);
                        double attributeWeight = weights.getWeight(attributeName);
                        if (attributeWeight > 0.0)
                            userWordList.add(attributeName);
                    }

                    wordList = wvt.createWordList(list, config, userWordList, false);

                } else {
                    wordList = wvt.createWordList(list, config);
                }
            }

            if (!isParameterSet("input_word_list"))
                pruneWordList(wordList);
            else
                log("Using external wordlist, no pruning is performed");

            // Extractor
            String featureExtractorClassName = null;
            FeatureExtractor extractorExt = null;

            if ((featureExtractorClassName != null) && (featureExtractorClassName.length()) > 0) {

                Class c = null;
                try {
                    c = Class.forName(featureExtractorClassName);
                    extractorExt = (FeatureExtractor) c.newInstance();
                } catch (Throwable t) {
                    extractorExt = null;
                    logWarning("Could not initialize the extractor. Ignoring it.");
                }
            }

            FeatureExtractor features = null;    
            
            AttributeQueryMap aqMap = null;
            try {
                aqMap = FeatureExtractionUtil.getAttributeQueryMap(getParameters());
            } catch (ExtractionException e3) {
                UserError error = e3.getUserError();
                error.setOperator(this);
                throw error;
            }

            if(aqMap.getAttributes().size() > 0)
                features = new DefaultFeatureExtractor(aqMap, config);
            FeatureExtractor combinedExtractor = null;
            
            if((extractorExt != null)&&(features != null)) {
                combinedExtractor = new ConcatanatedFeatureExtractor(new FeatureExtractor[]{extractorExt, features});
            } else {
                if(extractorExt != null)
                    combinedExtractor = extractorExt;
                else
                    if(features != null)
                        combinedExtractor = features;
            } 
            
            ExampleTableOutputFilter out = new ExampleTableOutputFilter(getLabel(), wordList,
                    getParameterAsBoolean("use_content_attributes"), getParameterAsInt(ID_ATTRIBUTE_TYPE), combinedExtractor, this);

            config.setConfigurationRule(WVTConfiguration.STEP_OUTPUT, new WVTConfigurationFact(out));
            // Create the vectors
            log("Creating word vectors.");
            wvt.createVectors(list, config, wordList);

            // Create TextVisualizer
            if (getParameterAsBoolean("create_text_visualizer")) {
                TextVisualizer textVis = new TextVisualizer(list, config, getParameterAsInt(ID_ATTRIBUTE_TYPE));
                ObjectVisualizerService.addObjectVisualizer(textVis);
            }

            // store word list?
            if (isParameterSet("output_word_list")) {
                File wordListFile = getParameterAsFile("output_word_list");
                try {
                    Writer wordListOut = new FileWriter(wordListFile);
                    wordList.store(wordListOut);
                } catch (IOException e) {
                    throw new UserError(this, 303, wordListFile, e.getMessage());
                }
            }

            return new IOObject[] { out.createExampleSet() };

        } catch (WVToolException e) {
            throw new UserError(this, e, 905, new Object[] { "wvtool", e });
        }
    }

    // ================================================================================

    public List<ParameterType> getParameterTypes() {
        List<ParameterType> types = super.getParameterTypes();
        types.add(new ParameterTypeString("default_content_type",
                "The default content type if not specified by the example set  (possible values: pdf, html, htm, xml, text, txt)..", ""));
        types.add(new ParameterTypeString("default_content_encoding",
                "The default content encoding if not specified by the example set (only encodings supported by Java can be used)..", ""));
        types.add(new ParameterTypeString("default_content_language",
                "The default content language if not specified by the example set.", ""));

        IMPLEMENTATION_MAPS = new ClassNameMapper[STEP_INTERFACES.length];

        for (int i = 0; i < STEPS.length; i++) {
            IMPLEMENTATION_MAPS[i] = new ClassNameMapper(KNOWN_IMPLEMENTATIONS[i]);
            types.add(new ParameterTypeStringCategory(STEPS[i], "Implementation class for step " + STEPS[i] + ".",
                    IMPLEMENTATION_MAPS[i].getShortClassNames(), DEFAULT_IMPLEMENTATIONS[i].getSimpleName()));
        }
        types
                .add(new ParameterTypeString(
                        "wvt_configuration",
                        "If the simple configuration specified by loader, inputfilter, ... does not suffice, an implementation of WVTConfiguration may be specified here.",
                        true));

        types
                .add(new ParameterTypeString(
                        "prune_below",
                        "Prune words that appear inat most that many documents. -1 for no pruning. Alternatively you can provide a percentage value, denoting the lowest document frequency in p words with the highest frequency.",
                        "-1"));
        types
                .add(new ParameterTypeString(
                        "prune_above",
                        "Prune words that appear in at least that many documents. -1 for no pruning. Alternatively you can provide a percentage value, denoting the highest document frequency in p words with the lowest frequency.",
                        "-1"));
        types
                .add(new ParameterTypeInt(
                        "min_chars",
                        "The minimum number of characters a word must contain to be processed (-1 for any). Note that this parameter works only with word filters derived from AbstractStopWordFilter",
                        0, Integer.MAX_VALUE, 4));
        types
        .add(new ParameterTypeFile(
                "add_stopwords",
                "A file that contains additional stopwords (one per line).","txt",true));
        
        types.add(new ParameterTypeInt("ngrams",
                "If this value is larger than zero, the operator creates character ngrams of the specified size.", 0,
                Integer.MAX_VALUE, 0));
        types
                .add(new ParameterTypeBoolean(
                        "use_content_attributes",
                        "If set to true, the returned example set will contain content type, encoding, and language attributes.",
                        false));
        types.add(new ParameterTypeFile("input_word_list",
                "Load a word list from this file instead of creating it from the input data.", null, true));
        types.add(new ParameterTypeFile("output_word_list", "Save the used word list into this file.", null, true));

        types
                .add(new ParameterTypeCategory(
                        ID_ATTRIBUTE_TYPE,
                        "Indicates if long ids (complete paths), short ids (last part of the source name), or numerical ids will be used.",
                        ExampleTableOutputFilter.ID_TYPE_NAMES, ExampleTableOutputFilter.ID_TYPE_NUMERICAL));

        ParameterType featuresType = FeatureExtractionUtil.createQueryParameter();
        featuresType.setExpert(true);
        types.add(featuresType);
        
        ParameterType param = FeatureExtractionUtil.createNamespaceParameter();
        types.add(param);
        
        ParameterType extractorParameter = new ParameterTypeString("text_query",
                "Query that extracts the parts of a document, that should be used for vectorization. This query can be XPath or a regular expression. If a regular expression is used, the query must have the following form: '<regex-expression> <replacement-pattern>', where the <replacement-pattern> states how a match is replaced to generate the final information. '$1' would yield the first matching group as result. For both, XPath and regular expression, all matches are concatanated and then passed to the vectorization process.");
        extractorParameter.setExpert(true);
        types.add(extractorParameter);
        
        types.add(new ParameterTypeBoolean("create_text_visualizer", "Indicates if a text specific object visualizer should be created which can be used in plotters etc.", false));
        
        return types;
    }
}
