package com.rapidminer.operator;

import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.util.TokenEnumeration;
import edu.udo.cs.wvtool.util.TokenEnumerationAdapter;
import edu.udo.cs.wvtool.util.WVToolException;

/**
 * Class that can be used to implement token processing operators.
 * 
 * @author Michael Wurst
 * @version $Id$
 *
 */
public abstract class AbstractTokenProcessor extends Operator {

    public AbstractTokenProcessor(OperatorDescription description) {
        super(description);
    }

    /**
     * Process a token enumeration.
     * 
     * @param tokens the token enumeration
     * @return a new token enumeration
     */
    protected abstract TokenEnumeration process(TokenEnumeration tokens, WVTDocumentInfo docInfo) throws WVToolException;
        
    public IOObject[] apply() throws OperatorException {

        TokenSequence sequence = getInput(TokenSequence.class);
        
        TokenSequence result;
        try {
            result = new TokenSequence(process(new TokenEnumerationAdapter(sequence.getTokenSequence()), sequence.getDocumentInfo() ), sequence.getDocumentInfo());
        } catch (WVToolException e) {
            
            throw new UserError(this, e, 905, new Object[] { "wvtool", e });

        }
        
        return new IOObject[] {result};
    }

    public Class[] getInputClasses() {
        return new Class[]{TokenSequence.class};
    }

    public Class[] getOutputClasses() {
        return new Class[]{TokenSequence.class};
    }

}
