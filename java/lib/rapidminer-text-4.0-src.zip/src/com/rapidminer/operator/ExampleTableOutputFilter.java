/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import com.rapidminer.example.Attribute;
import com.rapidminer.example.ExampleSet;
import com.rapidminer.example.table.AttributeFactory;
import com.rapidminer.example.table.DataRow;
import com.rapidminer.example.table.DoubleSparseArrayDataRow;
import com.rapidminer.example.table.ListDataRowReader;
import com.rapidminer.example.table.MemoryExampleTable;
import com.rapidminer.operator.extraction.ExtractionException;
import com.rapidminer.operator.extraction.FeatureExtractor;
import com.rapidminer.tools.LoggingHandler;
import com.rapidminer.tools.Ontology;

import edu.udo.cs.wvtool.generic.output.WVTOutputFilter;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.main.WVTWordVector;
import edu.udo.cs.wvtool.wordlist.WVTWordList;

/**
 * Class used to construct an example set using the word vector tool library.
 * 
 * @author Ingo Mierswa, Michael Wurst
 * @version $Id: ExampleTableOutputFilter.java,v 1.2 2007/07/19 13:49:05 mjwurst Exp $
 * 
 */
public class ExampleTableOutputFilter implements WVTOutputFilter {

    public static final int ID_TYPE_LONG = 0;

    public static final int ID_TYPE_SHORT = 1;

    public static final int ID_TYPE_NUMERICAL = 2;

    public static final String[] ID_TYPE_NAMES = { "long", "short", "number" };

    private final MemoryExampleTable exampleTable;

    private final List<DataRow> vectors = new LinkedList<DataRow>();

    private final boolean useSpecialAttributes;

    private final int idType;

    private int counter = 1;

    private final Attribute[] wordAttributes;

    private final Collection<Attribute> extractorAttributes;

    private final Attribute idAtt;

    private final Attribute sourceAtt = AttributeFactory.createAttribute("text_source", Ontology.NOMINAL);

    private final Attribute typeAtt = AttributeFactory.createAttribute("content_type", Ontology.NOMINAL);

    private final Attribute encodingAtt = AttributeFactory.createAttribute("content_encoding", Ontology.NOMINAL);

    private final Attribute languageAtt = AttributeFactory.createAttribute("content_language", Ontology.NOMINAL);

    private final Attribute labelAtt;

    private final FeatureExtractor extractor;

    private final LoggingHandler logger;
    
    /**
     * Constructor for the ExampleTableOutputFilter.
     * 
     * @param classAttribute the class attribute
     * @param wordList a word list
     * @param useSpecialAttributes if true, some meta data features are constructed
     * @param idType type of IDs
     * @param extractor feature extractor class (maybe null)
     */
    public ExampleTableOutputFilter(Attribute classAttribute, WVTWordList wordList, boolean useSpecialAttributes,
            int idType, FeatureExtractor extractor, LoggingHandler logger) {

        this.logger = logger;
        Set<String> attributeNames = new HashSet<String>();
        this.useSpecialAttributes = useSpecialAttributes;
        this.idType = idType;
        if (classAttribute != null)
            this.labelAtt = (Attribute) classAttribute.clone();
        else
            this.labelAtt = null;
        this.extractor = extractor;

        logger.log("Total number of words is " + wordList.getNumWords());

        List<Attribute> attributes = new LinkedList<Attribute>();
        if (this.idType == ID_TYPE_NUMERICAL) {
            idAtt = AttributeFactory.createAttribute("id", Ontology.INTEGER);
        } else {
            idAtt = AttributeFactory.createAttribute("id", Ontology.NOMINAL);
        }
        attributes.add(idAtt);
        attributeNames.add(idAtt.getName());
        this.wordAttributes = new Attribute[wordList.getNumWords()];
        if (useSpecialAttributes) {
            attributes.add(sourceAtt);
            attributes.add(typeAtt);
            attributes.add(encodingAtt);
            attributes.add(languageAtt);
            attributeNames.add(sourceAtt.getName());
            attributeNames.add(typeAtt.getName());
            attributeNames.add(encodingAtt.getName());
            attributeNames.add(languageAtt.getName());
        }

        String labelAttName = "";
        if (labelAtt != null) {
            labelAttName = labelAtt.getName();
            attributeNames.add(classAttribute.getName());
        }

        for (int i = 0; i < wordAttributes.length; i++) {
            String attributeName = null;
            if (!wordList.getWord(i).equals(labelAttName))
                attributeName = wordList.getWord(i);
            else {
                attributeName = labelAttName + "_";
                logger.logWarning("There is a term that equals the class attribute, renaming it");
            }
            attributeNames.add(attributeName);
            Attribute a = AttributeFactory.createAttribute(attributeName, Ontology.REAL);
            attributes.add(a);
            wordAttributes[i] = a;
        }

        if (extractor != null) {
            extractorAttributes = extractor.getAttributes();
            for (Iterator<Attribute> it = extractorAttributes.iterator(); it.hasNext();) {
                Attribute att = it.next();
                if (attributeNames.contains(att.getName())) {
                    it.remove();
                    logger.log(
                            "The extractor added an attribute with a name that is already used by another attribute: ["
                                    + att.getName() + "]. This attribute is omitted. Please rename this attribute and rerun.");
                }
                else {
                    attributes.add(att);
                }
            }
        } else {
            extractorAttributes = new LinkedList<Attribute>();
        }
        
        if (labelAtt != null)
            attributes.add(labelAtt);
        
        exampleTable = new MemoryExampleTable(attributes);
    }

    public void write(WVTWordVector wordVector){
        // convert WFTWordVector to DataRow
        WVTDocumentInfo docInfo = wordVector.getDocumentInfo();
        DataRow row = new DoubleSparseArrayDataRow(wordVector.getValues().length + extractorAttributes.size());
        String sourceName = docInfo.getSourceName();

        // id
        if (idType == ID_TYPE_NUMERICAL) {
            row.set(idAtt, counter++);
        } else {
            String idString = sourceName;
            if (idType == ID_TYPE_SHORT)
                idString = sourceName.substring(sourceName.lastIndexOf(java.io.File.separator) + 1);
            row.set(idAtt, idAtt.getMapping().mapString(idString));
        }

        if (useSpecialAttributes) {
            row.set(sourceAtt, sourceAtt.getMapping().mapString(docInfo.getSourceName()));
            row.set(typeAtt, typeAtt.getMapping().mapString(docInfo.getContentType()));
            row.set(encodingAtt, encodingAtt.getMapping().mapString(docInfo.getContentEncoding()));
            row.set(languageAtt, languageAtt.getMapping().mapString(docInfo.getContentLanguage()));
        }

        if (labelAtt != null)
            row.set(labelAtt, docInfo.getClassValue());
        double[] values = wordVector.getValues();
        for (int i = 0; i < values.length; i++)
            if (Double.isInfinite(values[i]) || Double.isNaN(values[i]))
                row.set(wordAttributes[i], 0.0);
            else
                row.set(wordAttributes[i], values[i]);

        try {
            if (extractor != null)
                extractor.extract(docInfo, row);
        } catch (ExtractionException e) {
            logger.logWarning("Could not extract any values for item '" + sourceName + "':" + e);
        }

        // trim the data row since the initialization might be too large
        row.trim();
        vectors.add(row);
    }

    public ExampleSet createExampleSet() throws OperatorException {
        if (exampleTable == null) {
            throw new OperatorException("WordVectorTool did not generate word vectors. Please check file names.");
        }
        exampleTable.readExamples(new ListDataRowReader(vectors.iterator()));
        return exampleTable.createExampleSet(labelAtt, null, idAtt);
    }
}
