package com.rapidminer.operator.wordfilter;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import com.rapidminer.operator.AbstractTokenProcessor;
import com.rapidminer.operator.IOObject;
import com.rapidminer.operator.OperatorDescription;
import com.rapidminer.operator.OperatorException;
import com.rapidminer.operator.UserError;
import com.rapidminer.parameter.ParameterType;
import com.rapidminer.parameter.ParameterTypeFile;
import com.rapidminer.parameter.UndefinedParameterError;

import edu.udo.cs.wvtool.generic.wordfilter.StopWordFilterFile;
import edu.udo.cs.wvtool.generic.wordfilter.WVTWordFilter;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.util.TokenEnumeration;
import edu.udo.cs.wvtool.util.WVToolException;

/**
 * Filters terms specified in an external file. The file must contain one term per line.
 * 
 * @author Michael Wurst
 * @version $Id$
 * 
 */
public class StopwordFilterFile extends AbstractTokenProcessor {

    private WVTWordFilter filter;

    public StopwordFilterFile(OperatorDescription description) {
        super(description);
    }

    protected TokenEnumeration process(TokenEnumeration tokens, WVTDocumentInfo docInfo) throws WVToolException {

        return filter.filter(tokens, docInfo);
    }

    public IOObject[] apply() throws OperatorException {

        try {
            filter = new StopWordFilterFile(0, new FileReader(getParameterAsFile("file")));
        } catch (UndefinedParameterError e) {
            // This cannot happen
        } catch (FileNotFoundException e) {
            throw new UserError(this, 302, new Object[] { getParameterAsFile("file").toString(), e });
        } catch (IOException e) {
            throw new UserError(this, 302, new Object[] { getParameterAsFile("file").toString(), e });
        }

        return super.apply();
    }

    public List<ParameterType> getParameterTypes() {

        List<ParameterType> types = super.getParameterTypes();

        types.add(new ParameterTypeFile("file", "File that contains the stopwords one per line", "txt", false));
        return types;
    }

}
