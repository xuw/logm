/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.rapidminer.operator.extraction.ExtractionException;
import com.rapidminer.operator.extraction.RegexExtractor;
import com.rapidminer.operator.extraction.TextExtractionWrapper;
import com.rapidminer.operator.extraction.TextExtractor;
import com.rapidminer.operator.extraction.XPathExtractor;
import com.rapidminer.operator.extraction.segmenter.RegexSegmenter;
import com.rapidminer.operator.extraction.segmenter.XPathSegmenter;
import com.rapidminer.operator.extraction.util.FeatureExtractionUtil;
import com.rapidminer.parameter.ParameterType;
import com.rapidminer.parameter.ParameterTypeDirectory;
import com.rapidminer.parameter.ParameterTypeString;
import com.rapidminer.parameter.UndefinedParameterError;


/**
 * Operator that allows to extract segments from a set of text documents in a directory
 * based on regular expressions or xpath. 
 * 
 * This operator does support only XML, HTML and text documents using the default encoding.
 * 
 * @author Michael Wurst
 * @version $Id: DocumentSegmenterOperator.java,v 1.2 2007/07/19 13:49:05 mjwurst Exp $
 *
 */
public class DocumentSegmenterOperator extends Operator {

    public DocumentSegmenterOperator(OperatorDescription description) {
        super(description);
    }

    public IOObject[] apply() throws OperatorException {
 
        Map<String,String> ns = FeatureExtractionUtil.getNamespaceMapping(getParameters());
        
        TextExtractor extractor = null;
        try {
            extractor = FeatureExtractionUtil.getExtractor(getParameterAsString("expression"), ns);
        } catch (UndefinedParameterError e1) {
            // This cannot happen!
        } catch (ExtractionException e1) {
 
            UserError error = e1.getUserError();
            error.setOperator(this);
            throw error;
            
        }
        
        com.rapidminer.operator.extraction.segmenter.DocumentSegmenter segmenter = null;
      
        if(extractor instanceof XPathExtractor)
            segmenter = new XPathSegmenter((XPathExtractor) extractor);
        else
            segmenter = new RegexSegmenter((RegexExtractor) extractor);

        File outDir = getParameterAsFile("output");
        
        // Read files
 
        int count = 0;
        File inDir = getParameterAsFile("texts");
        File[] files = inDir.listFiles();
        for(int i = 0; i < files.length; i++) 
            if(files[i].isFile()) {
            
                try {
                    int type = TextExtractionWrapper.determineType(files[i]);
                    
                    Iterator<String> segments = segmenter.getSegements(new FileInputStream(files[i]), type);
                    while(segments.hasNext()) {
                        
                        String outFileName = outDir.getAbsolutePath() + File.separator + "seg" + count + ".txt";
                        try {
                            Writer out = new BufferedWriter(new FileWriter(outFileName));
                            
                            out.write(segments.next());
                            out.close();
                        } catch (IOException e) {
                            throw new UserError(this, 303, new Object[]{outFileName, e});
                        }
                        
                        count++;
                    }
                } catch (FileNotFoundException e) {
                    throw new UserError(this, 301, new Object[]{files[i]});
                } catch (ExtractionException e) {
                    UserError error = e.getUserError();
                    error.setOperator(this);
                    throw error;
                }
            }
        
        return new IOObject[0];
    }

    public Class[] getInputClasses() {
        return new Class[0];
    }

    public Class[] getOutputClasses() {
        return new Class[0];
    }

    public List<ParameterType> getParameterTypes() {
        List<ParameterType> types = new LinkedList<ParameterType>();
        types.add(new ParameterTypeDirectory("texts", "A directory containing the documents to be segmented", false));
        types.add(new ParameterTypeDirectory("output", "The directory to which to write the segments", false));
        types.add(new ParameterTypeString("expression", "Specifies a regular expression or XPath expression that matches against substrings of the content which should be treated as individual segments. The syntax is the same as for attribute extraction (see WVTool operator), but instead of extracting only the first match, all matches are extracted and written to individual files", false));
        types.add(FeatureExtractionUtil.createNamespaceParameter());
        return types;
    }
    
}
