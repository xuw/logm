/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator.extraction;

import java.util.Iterator;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import com.rapidminer.operator.extraction.util.RegexPatternIterator;


/**
 * Extracts information based on regular expressions.
 * 
 * Note: This class ensures, that if two extractors use the same query,
 * they are treated as equal.
 * 
 * @author Michael Wurst
 * @version $Id: RegexExtractor.java,v 1.1 2007/05/27 21:45:35 ingomierswa Exp $
 *
 */
public class RegexExtractor implements TextExtractor {

    private final String targetTemplate;
    private final Pattern pattern;
    private final String query;
    
    /**
     * Construct an extractor.
     * 
     * @param query the query. If composed of two space separated expressions, the second one is interpreted as replacement string enabling reference to matching groups in the pattern defined by the substring before the last whitespace. Otherwise, the whole matched sequence is returned.
     */
    public RegexExtractor(String query) throws PatternSyntaxException {
    
        this.query = query;
        int index = query.lastIndexOf(' ');
        if (index > 0) {
            this.pattern = Pattern.compile(query.substring(0, index));
            targetTemplate = query.substring(index + 1);
        }
        else {
            // If the user does not specify a target template, use the entire matched sequence
            this.pattern = Pattern.compile(query);
            this.targetTemplate = "$0";
        }
        
    }
    
    /**
     * Get an iterator of string that represents the (replaced) patterns in the given string.
     * 
     * @param s the string that is searched for patterns
     * @return an iteration of strings representing (replaced) patterns
     */
    public Iterator<String> findPatterns(String s) {
       
        return new RegexPatternIterator(pattern.matcher(s), targetTemplate);
    }
   
    
    public boolean equals(Object obj) {
        return query.equals(obj.toString());
    }

    public int hashCode() {
        return query.hashCode();
    }

    public String toString() {
        return query;
    }
   
}
