/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator.extraction;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.util.Iterator;
import java.util.LinkedList;

import org.ccil.cowan.tagsoup.Parser;
import org.jaxen.JaxenException;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.xml.sax.XMLReader;

import com.rapidminer.operator.UserError;

import edu.udo.cs.wvtool.config.WVTConfiguration;
import edu.udo.cs.wvtool.generic.inputfilter.TextInputFilter;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.main.WVTool;
import edu.udo.cs.wvtool.util.WVToolException;

/**
 * Class performs extraction from text/html by delegating XPath and Regex queries.
 * 
 * @author Michael Wurst
 * @version $Id: TextExtractionWrapper.java,v 1.1 2007/05/27 21:45:35 ingomierswa Exp $
 * 
 */
public class TextExtractionWrapper {

    public static final int CONTENT_TYPE_TEXT = 0;
    public static final int CONTENT_TYPE_XML = 1;
    public static final int CONTENT_TYPE_HTML = 2;
    public static final int CONTENT_TYPE_PDF = 3;

    
    private String content;
    private int contentType;
    
    private org.jdom.Document dom = null;

    /**
     * Prepare the wrapper for the extraction of information from a string.
     * 
     * @param content the document content
     * @param contentType the type of content
     */
    public TextExtractionWrapper(String content, int contentType) {

        this.content = content;
        this.contentType = contentType;
    }

    /**
     * Prepare the wrapper for the extraction of information from a stream.
     * Notice: This method does use the default content encoding and should
     * therefore only be used for XML and HTML content that provides information
     * about its encoding.
     * 
     * @param inStream the stream from which to extract
     * @param contentType the type of content (text, html, etc.)
     * 
     */
    public TextExtractionWrapper(InputStream inStream, int contentType) throws ExtractionException {

        try {
            this.contentType = contentType;
            if((contentType == TextExtractionWrapper.CONTENT_TYPE_HTML)||(contentType == TextExtractionWrapper.CONTENT_TYPE_HTML))
                readXMLBasedDocument(inStream, null);
      
            readTextBasedDocument(new InputStreamReader(inStream));
       
        } catch (IOException e) {
            throw new ExtractionException("", e, new UserError(null,302,new Object[] {"unknown",e}));
        }
        
    }

    /**
     * Prepare the wrapper for the extraction of information from a document.
     * Depending on the type of document and the configuration of the operator,
     * different steps are taken. Text based documents are read using the selected
     * input filter. XML and HTML documents are parsed into a DOM Tree to which XPath
     * queries can be applied directly. For regex queries, this DOM Tree is converted
     * into text.
     * 
     * @param info
     * @param config
     */
    public TextExtractionWrapper(WVTDocumentInfo info, WVTConfiguration config) throws ExtractionException {

        WVTool wvtool = new WVTool(false);
        
        contentType = TextExtractionWrapper.CONTENT_TYPE_TEXT;
        int contentTypeWVTool = WVTConfiguration.determineType(info);

        switch (contentTypeWVTool) {
        case WVTConfiguration.TYPE_HTML:
            contentType = TextExtractionWrapper.CONTENT_TYPE_HTML;
            break;
        case WVTConfiguration.TYPE_XML:
            contentType = TextExtractionWrapper.CONTENT_TYPE_XML;
            break;
        case WVTConfiguration.TYPE_TEXT:
            contentType = TextExtractionWrapper.CONTENT_TYPE_TEXT;
            break;
        default:
            contentType = TextExtractionWrapper.CONTENT_TYPE_TEXT;
            break;
        }
        
        try {
            if((contentType == TextExtractionWrapper.CONTENT_TYPE_XML)||(contentType == TextExtractionWrapper.CONTENT_TYPE_HTML)||
                    config.getComponentForStep(WVTConfiguration.STEP_INPUT_FILTER, info) instanceof ExtractingInputFilter) {
                readXMLBasedDocument(wvtool.getInputStream(info, config), info);
                TextInputFilter txtFilter = new TextInputFilter();
                Reader inReader = txtFilter.convertToPlainText(wvtool.getInputStream(info, config), info);
                readTextBasedDocument(inReader);
            }
            else {
                // To avoid loops
                if(!(config.getComponentForStep(WVTConfiguration.STEP_INPUT_FILTER, info) instanceof ExtractingInputFilter))
                    readTextBasedDocument(wvtool.getReader(info, config));
                else {
                    TextInputFilter txtFilter = new TextInputFilter();
                    Reader inReader = txtFilter.convertToPlainText(wvtool.getInputStream(info, config), info);
                    readTextBasedDocument(inReader);
                }
            }
        } catch (IOException e2) {
            throw new ExtractionException("", e2, new UserError(null,302,new Object[] {info.getSourceName(),e2}));
            } catch (WVToolException e2) {
            throw new ExtractionException("", e2, new UserError(null,306,new Object[] {"WVTool",e2}));
                
        }
    }
    
    /**
     * Extract values based on regular expressions
     * 
     * @param extr the extractor
     * @return an iteration of strings
     */
    public Iterator<String> getValues(TextExtractor extr) throws ExtractionException {

        if(extr instanceof RegexExtractor)
            return getValues((RegexExtractor) extr);
        else
            return getValues((XPathExtractor) extr);
    }
    
    /**
     * Extract values based on regular expressions
     * 
     * @param extr the extractor
     * @return an iteration of strings
     */
    public Iterator<String> getValues(RegexExtractor extr) {

        return extr.findPatterns(content);
    }

    /**
     * Extract values based on an XPath expression
     * 
     * @param xpathExtractor the query
     * @return an iteration of strings
     */
    public Iterator<String> getValues(XPathExtractor xpathExtractor) throws ExtractionException {
        
        Iterator<String> result = null;
        
        try {
            if (dom == null) {
                
                SAXBuilder builder = null;
                
                if(contentType == CONTENT_TYPE_HTML)
                    builder = new TagSoupSAXBuilder();
                else
                    builder = new SAXBuilder();
                
                dom = builder.build(new StringReader(content));

            }
            
            result = xpathExtractor.findPatterns(dom);
        
        } catch (JaxenException e) {
            throw new ExtractionException("", e, new UserError(null,401,new Object[] {e}));

        } catch (JDOMException e) {
            throw new ExtractionException("", e, new UserError(null,401,new Object[] {e}));
            
        } catch (IOException e) {
            throw new ExtractionException("", e, new UserError(null,302,new Object[] {"unknown",e}));    
        }

        if(result != null)
            return result;
        else
            return new LinkedList<String>().iterator();
    }

    private void readXMLBasedDocument(InputStream inStream, WVTDocumentInfo docInfo) throws ExtractionException, IOException {

        if((contentType == CONTENT_TYPE_HTML)||(contentType==CONTENT_TYPE_XML)) {
        try {
            if (dom == null) {
                
                SAXBuilder builder = null;
                
                if(contentType == CONTENT_TYPE_HTML) {
                    builder = new TagSoupSAXBuilder();
                    
                    if(docInfo != null) {
                        TextInputFilter txtFilter = new TextInputFilter();
                        dom = builder.build(txtFilter.convertToPlainText(inStream, docInfo));
                    }
                    else
                        dom = builder.build(inStream);
                }
                else {
                    builder = new SAXBuilder();
                    dom = builder.build(inStream);
                }
            }
                    
        } catch (JDOMException e) {
            throw new ExtractionException("", e, new UserError(null,401,new Object[] {e}));
        }
        
        
        }

       
        
    }

    private void readTextBasedDocument(Reader inReader) throws ExtractionException, IOException {

        StringBuffer contentBuf = new StringBuffer();

            BufferedReader in = new BufferedReader(inReader);
            String buf = null;

            while ((buf = in.readLine()) != null) {
                contentBuf.append(buf);
                contentBuf.append("\n");
            }

            in.close();

            content = contentBuf.toString();
            
        }
    
    
    /**
     * Determines the type of file using some heuristics.
     * 
     * @param f the file
     * @return an int representing a file type
     */
    public static int determineType(File f) {

        String sourceName = f.getName();
        String typeStr = "";
            
        int index = sourceName.lastIndexOf('.');
        if(index >= 0)
            typeStr = sourceName.substring(index + 1);            
            
        if(typeStr.equalsIgnoreCase("htm"))
            typeStr = "html";
        
        if(typeStr.equalsIgnoreCase("pdf"))
            return CONTENT_TYPE_PDF;
        
        if(typeStr.equalsIgnoreCase("html"))
            return CONTENT_TYPE_HTML;
        
        if(typeStr.equalsIgnoreCase("xml"))
            return CONTENT_TYPE_XML;
        
        
        return CONTENT_TYPE_TEXT;
        
    }

}

/**
 * Pseudoclass to make the JDOM Parser use the tagsoup SAX Parser.
 * 
 * @author Michael Wurst
 * @version $Id: TextExtractionWrapper.java,v 1.1 2007/05/27 21:45:35 ingomierswa Exp $
 *
 */
class TagSoupSAXBuilder extends SAXBuilder {

    @Override
    protected XMLReader createParser() throws JDOMException {
        
        XMLReader result = new Parser();
        return result;
    }
    
    
    
}

