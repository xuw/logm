/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator.extraction.util;

import java.util.Iterator;
import java.util.regex.Matcher;

/**
 * Searches a string using a regular expression matcher and returns the matched results.
 * 
 * @author Michael Wurst
 * @version $Id: RegexPatternIterator.java,v 1.1 2007/05/27 21:45:36 ingomierswa Exp $
 *
 */
public class RegexPatternIterator implements Iterator<String>{

    private final Matcher m;
    private final String replacementStr;
    private boolean hasMorePattern;
    private int lastAppendPosition = 0;
    
    /**
     * Construct a pattern iterator.
     * 
     * @param m the matcher that is used
     * @param str the replacement string (e.g "$1")
     */
    public RegexPatternIterator(Matcher m, String str) {
        super();

        this.m = m;
        replacementStr = str;
        hasMorePattern = m.find();
    }

    public boolean hasNext() {

        return hasMorePattern;
    }

    public String next() {

        StringBuffer buf = new StringBuffer();
        m.appendReplacement(buf, replacementStr);
        String result = buf.substring(m.start() - lastAppendPosition);
        lastAppendPosition = m.end();
        hasMorePattern = m.find();
         return result;
    }

    public void remove() {
       
        // Not implemented
    }
}
