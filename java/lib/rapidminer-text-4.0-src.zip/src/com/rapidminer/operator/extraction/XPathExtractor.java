/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator.extraction;

import java.io.IOException;
import java.io.StringWriter;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.jaxen.JaxenException;
import org.jaxen.jdom.JDOMXPath;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.Text;
import org.jdom.output.XMLOutputter;

import com.rapidminer.operator.UserError;

/**
 * Extracts information based on an XPath query. If the XPath expression leads to an element,
 * this element is converted to text, if it leads to a text node, the text is extracted.
 * In any other case, the query will not produce any result.
 * Note: This class ensures, that if two extractors use the same query,
 * they are treated as equal.
 * 
 * @author Michael Wurst
 * @version $Id: XPathExtractor.java,v 1.1 2007/05/27 21:45:35 ingomierswa Exp $
 *
 */
public class XPathExtractor implements TextExtractor {

    private String query;
    
    private JDOMXPath xpathExpression;

    /**
     * Constructs the xpath extractor.
     * 
     * @param query an XPath query expression
     */
    public XPathExtractor(String query, Map<String,String> nameSpaceMap) throws  JaxenException {
        super();
        this.query = query;
        
        xpathExpression = new JDOMXPath(query);
        xpathExpression.addNamespace("h","http://www.w3.org/1999/xhtml");
        for(String id: nameSpaceMap.keySet())
            xpathExpression.addNamespace(id, nameSpaceMap.get(id));
        
        }

    public JDOMXPath getXPathExpression() {
        
        return xpathExpression;
    }
    
    public Iterator<String> findPatterns(Document dom) throws JaxenException, ExtractionException {
        
        List<String> result = new LinkedList<String>();

            XMLOutputter out = new XMLOutputter();
            
            List nodes = xpathExpression.selectNodes(dom);
           for (Object obj : nodes) {
               
                StringWriter w = new StringWriter();
                
                    try {
                        if(obj instanceof Element)
                            out.output((Element) obj, w);
                        else if(obj instanceof Attribute)
                            w.write(((Attribute) obj).getValue());
                        else
                            out.output((Text) obj, w);
                        
                        result.add(w.getBuffer().toString());
                    } catch (IOException e) {
                        throw new ExtractionException("", e, new UserError(null,401,new Object[] {e}));
                    }
                    
            }
        
        return result.iterator();
    }
    
    public boolean equals(Object obj) {
        return query.equals(obj.toString());
    }

    public int hashCode() {
        return query.hashCode();
    }

    public String toString() {
        return query;
    }
}
