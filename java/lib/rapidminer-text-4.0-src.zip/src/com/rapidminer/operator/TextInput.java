package com.rapidminer.operator;

/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.rapidminer.example.Attribute;
import com.rapidminer.example.AttributeWeights;
import com.rapidminer.example.ExampleSet;
import com.rapidminer.operator.condition.InnerOperatorCondition;
import com.rapidminer.operator.condition.LastInnerOperatorCondition;
import com.rapidminer.operator.extraction.ExtractingInputFilter;
import com.rapidminer.operator.extraction.ExtractionException;
import com.rapidminer.operator.extraction.TextExtractor;
import com.rapidminer.operator.extraction.util.FeatureExtractionUtil;
import com.rapidminer.parameter.ParameterType;
import com.rapidminer.parameter.ParameterTypeBoolean;
import com.rapidminer.parameter.ParameterTypeCategory;
import com.rapidminer.parameter.ParameterTypeFile;
import com.rapidminer.parameter.ParameterTypeString;
import com.rapidminer.parameter.ParameterTypeStringCategory;
import com.rapidminer.parameter.UndefinedParameterError;
import com.rapidminer.tools.ObjectVisualizerService;

import edu.udo.cs.wvtool.config.WVTConfiguration;
import edu.udo.cs.wvtool.config.WVTConfigurationFact;
import edu.udo.cs.wvtool.generic.vectorcreation.WVTVectorCreator;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.main.WVTInputList;
import edu.udo.cs.wvtool.main.WVTTokenSequence;
import edu.udo.cs.wvtool.main.WVTool;
import edu.udo.cs.wvtool.util.WVToolException;
import edu.udo.cs.wvtool.util.WVToolLogger;
import edu.udo.cs.wvtool.wordlist.WVTWordList;

/**
 * This is the abstract superclass for all word vector creation operators. It expects several suboperators that process a stream of tokens.
 * 
 * @author Michael Wurst, Ingo Mierswa
 * @version $Id: TextInput.java,v 1.1 2007/07/27 22:46:06 ingomierswa Exp $
 */
public abstract class TextInput extends OperatorChain {

    public static final String ID_ATTRIBUTE_TYPE = "id_attribute_type";

    public static Class[] vectorCreation = new Class[] { edu.udo.cs.wvtool.generic.vectorcreation.TermFrequency.class, edu.udo.cs.wvtool.generic.vectorcreation.TermOccurrences.class, edu.udo.cs.wvtool.generic.vectorcreation.TFIDF.class, edu.udo.cs.wvtool.generic.vectorcreation.BinaryOccurrences.class };

    private ClassNameMapper vectorCreationMapper;

    // ================================================================================

    private WVTool wvt = new WVTool(false);

    private WVTConfiguration config;

    public TextInput(OperatorDescription description) {
        super(description);
    }

    protected abstract WVTInputList createInputList() throws OperatorException;

    protected abstract Attribute getLabel() throws OperatorException;

    protected abstract WVTConfiguration createConfiguration() throws OperatorException;
    
    // ================================================================================

    
    private WVTWordList createWordList(WVTInputList inputList, List words, boolean append) throws WVToolException, OperatorException {

        WVTWordList wordList = null;

        if (words != null)
            wordList = new WVTWordList(words, inputList.getNumClasses());
        else
            wordList = new WVTWordList(inputList.getNumClasses());

        Iterator it = inputList.getEntries();
        while (it.hasNext()) {

            WVTDocumentInfo docInfo = (WVTDocumentInfo) it.next();
            WVTTokenSequence tokens = getTokenSequence(docInfo);
            wvt.addToWordList(wordList, tokens, append);

        }

        return wordList;
    }

    private WVTTokenSequence getTokenSequence(WVTDocumentInfo docInfo) throws OperatorException {

        TokenSequence result = null;

        try {

            BufferedReader in = new BufferedReader(wvt.getReader(docInfo, config));

            StringBuffer buffer = new StringBuffer();
            String line = null;

            while ((line = in.readLine()) != null) {
                buffer.append(line);
                buffer.append(' ');
            }
            in.close();

            TokenSequence sequence = new TokenSequence(buffer.toString(), docInfo);

            IOContainer container = new IOContainer(sequence);
            for (int i = 0; i < getNumberOfOperators(); i++)
                container = getOperator(i).apply(container);

            result = container.get(TokenSequence.class);
        } catch (MissingIOObjectException e) {
            throw new UserError(this, e, 127, new Object[] { e });
        } catch (IOException e) {
            throw new UserError(this, e, 302, new Object[] { docInfo.getSourceName(), e });
        } catch (WVToolException e) {
            throw new UserError(this, e, 905, new Object[] { "wvtool", e });
        }

        return result;
    }

    private void pruneWordList(WVTWordList wordList) throws UndefinedParameterError {
        // Prune the word list
        String pruneBelowStr = (String) getParameter("prune_below");
        String pruneAboveStr = (String) getParameter("prune_above");
        int pruneBelow = -1;
        int pruneAbove = -1;

        try {
            if (pruneBelowStr.charAt(pruneBelowStr.length() - 1) == '%') {

                pruneBelowStr = pruneBelowStr.substring(0, pruneBelowStr.length() - 1);
                double rankFraction = 1.0 - (Double.parseDouble(pruneBelowStr) / 100.0);
                pruneBelow = wordList.getFrequencyByRank((int) Math.max(wordList.getNumWords() * rankFraction, 1));

            } else {
                pruneBelow = Integer.parseInt(pruneBelowStr);
            }
        } catch (NumberFormatException e) {
            logError("Could not parse the parameter prune_below: " + e.getMessage());
        }

        try {
            if (pruneAboveStr.charAt(pruneAboveStr.length() - 1) == '%') {

                pruneAboveStr = pruneAboveStr.substring(0, pruneAboveStr.length() - 1);
                double rankFraction = Double.parseDouble(pruneAboveStr) / 100.0;
                pruneAbove = wordList.getFrequencyByRank((int) Math.max(wordList.getNumWords() * rankFraction, 1));
            } else {
                pruneAbove = Integer.parseInt(pruneAboveStr);
            }
        } catch (NumberFormatException e) {
            logError("Could not parse the parameter prune_above: " + e.getMessage());
        }

        if ((pruneBelow >= 0) || (pruneAbove >= 0)) {
            log("Pruning word list.");
            wordList.pruneByFrequency(pruneBelow < 0 ? 0 : pruneBelow, pruneAbove < 0 ? Integer.MAX_VALUE : pruneAbove);
        }
    }

    // ================================================================================

    public IOObject[] apply() throws OperatorException {
        
        config = createConfiguration();
        WVToolLogger.setGlobalLogger(new WVToolRapidMinerLogger(this));

        // ------------ Configuration --------------------------------
        String textExtractorStr = getParameterAsString("text_query");
        if (textExtractorStr != null) {

            TextExtractor textExtractor = null;
            try {
                textExtractor = FeatureExtractionUtil.getExtractor(textExtractorStr, FeatureExtractionUtil.getNamespaceMapping(getParameters()));
            } catch (ExtractionException e) {

                UserError error = e.getUserError();
                error.setOperator(this);
                throw error;

            }

            ExtractingInputFilter extrInFilter = new ExtractingInputFilter(config, textExtractor);
            config.setConfigurationRule(WVTConfiguration.STEP_INPUT_FILTER, new WVTConfigurationFact(extrInFilter));
        }

        WVTVectorCreator vectorCreator = (WVTVectorCreator) vectorCreationMapper.getInstantiation(getParameterAsString("vector_creation"));

        // ------------ Input List --------------------------------

        WVTInputList list = createInputList();

        // ------------ Wordllist --------------------------------
        try {

            boolean userWordListMode = true;
            AttributeWeights weights = null;

            try {
                weights = getInput(AttributeWeights.class);
            } catch (Exception e) {
                userWordListMode = false;
                weights = null;
            }

            WVTWordList wordList = null;
            if (isParameterSet("input_word_list")) {
                if (userWordListMode) {
                    logWarning("Input attribute weights are ignored for word list loaded from file.");
                }
                File wordListFile = getParameterAsFile("input_word_list");
                try {
                    Reader wordListIn = new BufferedReader(new FileReader(wordListFile));
                    wordList = new WVTWordList(wordListIn);
                } catch (IOException e) {
                    throw new UserError(this, 302, wordListFile, e.getMessage());
                }
            } else {
                if (userWordListMode) {

                    LinkedList<String> userWordList = new LinkedList<String>();
                    List<String> attributeNames = new LinkedList<String>(weights.getAttributeNames());

                    for (int j = 0; j < attributeNames.size(); j++) {
                        String attributeName = attributeNames.get(j);
                        double attributeWeight = weights.getWeight(attributeName);
                        if (attributeWeight > 0.0)
                            userWordList.add(attributeName);
                    }

                    wordList = createWordList(list, userWordList, false);

                } else {
                    wordList = createWordList(list, null, true);
                }
            }

            if (!isParameterSet("input_word_list"))
                pruneWordList(wordList);
            else
                log("Using external wordlist, no pruning is performed");

            ExampleTableOutputFilter out = new ExampleTableOutputFilter(getLabel(), wordList, getParameterAsBoolean("use_content_attributes"), getParameterAsInt(ID_ATTRIBUTE_TYPE), null, this);

            // Write word vectors
            Iterator it = list.getEntries();
            while (it.hasNext()) {

                WVTDocumentInfo docInfo = (WVTDocumentInfo) it.next();
                WVTTokenSequence tokens = getTokenSequence(docInfo);
                out.write(wvt.createVector(tokens, vectorCreator, wordList));

            }

            // Create TextVisualizer
            if (getParameterAsBoolean("create_text_visualizer")) {
                TextVisualizer textVis = new TextVisualizer(list, config, getParameterAsInt(ID_ATTRIBUTE_TYPE));
                ObjectVisualizerService.addObjectVisualizer(textVis);
            }

            // Write wordlist
            if (isParameterSet("output_word_list")) {
                File wordListFile = getParameterAsFile("output_word_list");
                try {
                    Writer wordListOut = new FileWriter(wordListFile);
                    wordList.store(wordListOut);
                } catch (IOException e) {
                    throw new UserError(this, 303, wordListFile, e.getMessage());
                }
            }

            return new IOObject[] { out.createExampleSet() };

        } catch (WVToolException e) {
            throw new UserError(this, e, 905, new Object[] { "wvtool", e });
        }
    }

    
    
    // ================================================================================

    public Class[] getInputClasses() {
        return new Class[0];
    }

    public Class[] getOutputClasses() {
        return new Class[] { ExampleSet.class };
    }

    public InnerOperatorCondition getInnerOperatorCondition() {
        return new LastInnerOperatorCondition(new Class[] { TokenSequence.class }, new Class[] { TokenSequence.class }, true);
    }

    public int getMaxNumberOfInnerOperators() {
        return Integer.MAX_VALUE;
    }

    public int getMinNumberOfInnerOperators() {
        return 0;
    }

    public List<ParameterType> getParameterTypes() {
        List<ParameterType> types = super.getParameterTypes();
        types.add(new ParameterTypeString("default_content_type", "The default content type if not specified by the example set  (possible values: pdf, html, htm, xml, text, txt).", ""));
        types.add(new ParameterTypeString("default_content_encoding", "The default content encoding if not specified by the example set (only encodings supported by Java can be used).", ""));
        types.add(new ParameterTypeString("default_content_language", "The default content language if not specified by the example set.", ""));

        types.add(new ParameterTypeString("prune_below", "Prune words that appear inat most that many documents. -1 for no pruning. Alternatively you can provide a percentage value, denoting the lowest document frequency in p words with the highest frequency.", "-1"));
        types.add(new ParameterTypeString("prune_above", "Prune words that appear in at least that many documents. -1 for no pruning. Alternatively you can provide a percentage value, denoting the highest document frequency in p words with the lowest frequency.", "-1"));

        String[] vectorizationClassNames = new String[vectorCreation.length];
        for (int i = 0; i < vectorCreation.length; i++)
            vectorizationClassNames[i] = vectorCreation[i].getCanonicalName();

        vectorCreationMapper = new ClassNameMapper(vectorizationClassNames);
        types.add(new ParameterTypeStringCategory("vector_creation", "Method used to create word vectors", vectorCreationMapper.getShortClassNames(), "TFIDF"));

        types.add(new ParameterTypeBoolean("use_content_attributes", "If set to true, the returned example set will contain content type, encoding, and language attributes.", false));

        types.add(new ParameterTypeFile("input_word_list", "Load a word list from this file instead of creating it from the input data.", null, true));

        types.add(new ParameterTypeFile("output_word_list", "Save the used word list into this file.", null, true));

        types.add(new ParameterTypeCategory(ID_ATTRIBUTE_TYPE, "Indicates if long ids (complete paths), short ids (last part of the source name), or numerical ids will be used.", ExampleTableOutputFilter.ID_TYPE_NAMES, ExampleTableOutputFilter.ID_TYPE_NUMERICAL));

        ParameterType param = FeatureExtractionUtil.createNamespaceParameter();
        types.add(param);

        ParameterType extractorParameter = new ParameterTypeString("text_query", "Query that extracts the parts of a document, that should be used for vectorization. This query can be XPath or a regular expression. If a regular expression is used, the query must have the following form: '<regex-expression> <replacement-pattern>', where the <replacement_pattern> states how a match is replaced to generate the final information. '$1' would yield the first matching group as result. For both, XPath and regular expression, all matches are concatanated and then passed to the vectorization process.");
        extractorParameter.setExpert(true);
        types.add(extractorParameter);

        types.add(new ParameterTypeBoolean("create_text_visualizer", "Indicates if a text specific object visualizer should be created which can be used in plotters etc. Note: Text visualization does not work for id type number.", false));

        return types;
    }
}
