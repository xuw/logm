package com.rapidminer.operator.reducer;

import com.rapidminer.operator.AbstractTokenProcessor;
import com.rapidminer.operator.OperatorDescription;

import edu.udo.cs.wvtool.generic.stemmer.FastGermanStemmer;
import edu.udo.cs.wvtool.generic.stemmer.WVTStemmer;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.util.TokenEnumeration;
import edu.udo.cs.wvtool.util.WVToolException;

/**
 * A simple german stemmer, based on the algorithm in the report
 * "A Fast and Simple Stemming Algorithm for German Words" by Joerg
 * Caumanns (joerg.caumanns@isst.fhg.de).
 *
 * 
 * @author Michael Wurst
 * @version $Id$
 *
 */
public class GermanStemmer extends AbstractTokenProcessor {

    private WVTStemmer stemmer = new FastGermanStemmer();
    
    public GermanStemmer(OperatorDescription description) {
        super(description);
    }

    
    
    protected TokenEnumeration process(TokenEnumeration tokens, WVTDocumentInfo docInfo) throws WVToolException {
        
        return stemmer.stem(tokens, docInfo);
    }

}
