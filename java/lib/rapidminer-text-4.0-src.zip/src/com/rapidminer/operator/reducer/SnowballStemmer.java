package com.rapidminer.operator.reducer;

import com.rapidminer.operator.AbstractTokenProcessor;
import com.rapidminer.operator.IOObject;
import com.rapidminer.operator.OperatorDescription;
import com.rapidminer.operator.OperatorException;

import edu.udo.cs.wvtool.generic.stemmer.SnowballStemmerWrapper;
import edu.udo.cs.wvtool.generic.stemmer.WVTStemmer;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.util.TokenEnumeration;
import edu.udo.cs.wvtool.util.WVToolException;

/**
 * The Snowball wrapper. This stemmer reads the value of the language attribute
 * and selects an appropriate stemmer from the snowball library accordingly.
 * Only languages supported by snowball library can be used.
 * 
 * @author Michael Wurst
 * @version $Id$
 *
 */
public class SnowballStemmer extends AbstractTokenProcessor {

    WVTStemmer stemmer;
    
    public SnowballStemmer(OperatorDescription description) {
        super(description);
    }

    public IOObject[] apply() throws OperatorException {
        
        try {
            stemmer = new SnowballStemmerWrapper();
        } catch (WVToolException e) {
            // This cannot happen
        }
        
        return super.apply();
    }

    protected TokenEnumeration process(TokenEnumeration tokens, WVTDocumentInfo docInfo) throws WVToolException {
        return stemmer.stem(tokens, docInfo);
    }

}
