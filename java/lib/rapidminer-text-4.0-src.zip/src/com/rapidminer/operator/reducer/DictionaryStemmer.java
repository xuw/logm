package com.rapidminer.operator.reducer;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import com.rapidminer.operator.AbstractTokenProcessor;
import com.rapidminer.operator.IOObject;
import com.rapidminer.operator.OperatorDescription;
import com.rapidminer.operator.OperatorException;
import com.rapidminer.operator.UserError;
import com.rapidminer.parameter.ParameterType;
import com.rapidminer.parameter.ParameterTypeFile;
import com.rapidminer.parameter.UndefinedParameterError;

import edu.udo.cs.wvtool.generic.stemmer.WVTStemmer;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.util.TokenEnumeration;
import edu.udo.cs.wvtool.util.WVToolException;

/**
 * Reduces terms to a base form using an external file with replacement rules.
 * The file must contain a rule per line:
 * 
 * targetExpression pattern1 pattern2 ...
 * 
 * where targetExpression is the term to which the input term is reduced, if it matches any of the patterns.
 * patterni is a simple string or a regular expression.
 * 
 * @author Michael Wurst
 * @version $Id$
 *
 */
public class DictionaryStemmer extends AbstractTokenProcessor {

    WVTStemmer stemmer;
    
    public DictionaryStemmer(OperatorDescription description) {
        super(description);
    }
    public IOObject[] apply() throws OperatorException {

    try {
        
        stemmer = new edu.udo.cs.wvtool.generic.stemmer.DictionaryStemmer(new FileReader(getParameterAsFile("file")));
        
    } catch (UndefinedParameterError e) {
        // This cannot happen
    } catch (FileNotFoundException e) {
        throw new UserError(this, 302, new Object[] { getParameterAsFile("file").toString(), e });
    } catch (IOException e) {
        throw new UserError(this, 302, new Object[] { getParameterAsFile("file").toString(), e });
    }
    
        return super.apply();
    }



    protected TokenEnumeration process(TokenEnumeration tokens, WVTDocumentInfo docInfo) throws WVToolException {

       return stemmer.stem(tokens, docInfo);
    }

    public List<ParameterType> getParameterTypes() {

        List<ParameterType> types = super.getParameterTypes();

        types.add(new ParameterTypeFile("file", "File that contains the dictionary. See operator reference for the file format.", "txt", false));
        return types;
    }

    

}
