package com.rapidminer.operator.tokenizer;

import com.rapidminer.operator.AbstractTokenProcessor;
import com.rapidminer.operator.OperatorDescription;

import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.util.TokenEnumeration;
import edu.udo.cs.wvtool.util.WVToolException;

/**
 * This class tokinizes all tokens in the input.
 * All characters that are not defined as letters in the Java Characters class,
 * are used as separators.
 * 
 * @author Michael Wurst
 * @version $Id$
 *
 */
public class SimpleTokenizer extends AbstractTokenProcessor {

    edu.udo.cs.wvtool.generic.tokenizer.StringTokenizer tokenizer = 
        new edu.udo.cs.wvtool.generic.tokenizer.StringTokenizer();
    
    public SimpleTokenizer(OperatorDescription description) {
        super(description);
    }

//    protected TokenEnumeration process(TokenEnumeration tokens, WVTDocumentInfo docInfo) throws WVToolException {
//
//        
//        List<String> outputTokens = new LinkedList<String>();
//        while(tokens.hasMoreTokens()) {
//            
//            java.util.StringTokenizer inputTokens = new java.util.StringTokenizer(tokens.nextToken(),"., !?()- ");
//            while(inputTokens.hasMoreTokens())
//                outputTokens.add(inputTokens.nextToken());
//            
//        }
//        
//        return new TokenEnumerationAdapter(outputTokens);
//    }

   protected TokenEnumeration process(TokenEnumeration tokens, WVTDocumentInfo docInfo) throws WVToolException {

  
        return tokenizer.tokenize(tokens, docInfo);
    }
    
}
