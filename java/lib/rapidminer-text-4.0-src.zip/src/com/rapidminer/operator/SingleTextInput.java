/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.rapidminer.example.Attribute;
import com.rapidminer.parameter.ParameterType;
import com.rapidminer.parameter.ParameterTypeText;
import com.rapidminer.parameter.TextType;

import edu.udo.cs.wvtool.config.WVTConfiguration;
import edu.udo.cs.wvtool.config.WVTConfigurationFact;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.main.WVTFileInputList;
import edu.udo.cs.wvtool.main.WVTInputList;

/**
 * <p>This operator takes a a single input text via a parameter. 
 * The result is a set of attributes representing word occurrence 
 * information from the text. The set of words (attributes) is 
 * determined from the given text or could be determined by an
 * input word list. The parameters and possible sub-operators
 * and restrictions are the same as for the WVTool2Operator.</p>
 * 
 * <p>This operator is especially useful if you want to process a 
 * single text. If you want to read more than one text directly 
 * from files we recommend the WVToolOperator of the Word Vector 
 * Tool plugin.</p>
 * 
 * @author Ingo Mierswa, Michael Wurst
 * @version $Id: SingleTextInput.java,v 1.1 2007/07/27 22:46:06 ingomierswa Exp $
 */
public class SingleTextInput extends TextInput {
    
    
    /** Creates a new operator instance. */
    public SingleTextInput(OperatorDescription description) {
        super(description);
    }

    protected Attribute getLabel() throws OperatorException {
        return null; 
    }
    
    protected WVTInputList createInputList() throws OperatorException {
        log("Creating WVTool input list from single text from parameter.");

        String contentType = getParameterAsString("default_content_type");
        String contentEncoding = getParameterAsString("default_content_encoding");
        String contentLanguage = getParameterAsString("default_content_language");

        WVTFileInputList list = new WVTFileInputList(0);
        
        String text = getParameterAsString("text");
        list.addEntry(new WVTDocumentInfo(text, contentType, contentEncoding, contentLanguage));
        
        return list;
    }

    protected WVTConfiguration createConfiguration() throws OperatorException {
        WVTConfiguration config = new WVTConfiguration();
        log("Creating WVTool configuration including source as text loader...");
        config.setConfigurationRule(WVTConfiguration.STEP_LOADER, new WVTConfigurationFact("edu.udo.cs.wvtool.generic.loader.SourceAsTextLoader"));
        return config;
    }

    
    
    public List<ParameterType> getParameterTypes() {
        List<ParameterType> types = new LinkedList<ParameterType>();
        types.add(new ParameterTypeText("text", "The input text.", TextType.PLAIN, false));
        types.addAll(super.getParameterTypes());
        
        // remove loader parameter
        Iterator i = types.iterator();
        while (i.hasNext()) {
            ParameterType type = (ParameterType) i.next();
            if (type.getKey().equals(WVTConfiguration.STEP_LOADER)) {
                i.remove();
                break;
            }
        }
        return types;
    }
}
