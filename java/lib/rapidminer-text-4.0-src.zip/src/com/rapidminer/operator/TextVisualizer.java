/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator;

import java.awt.Insets;
import java.io.BufferedReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

import com.rapidminer.ObjectVisualizer;
import com.rapidminer.tools.LogService;

import edu.udo.cs.wvtool.config.WVTConfiguration;
import edu.udo.cs.wvtool.main.WVTDocumentInfo;
import edu.udo.cs.wvtool.main.WVTInputList;
import edu.udo.cs.wvtool.main.WVTool;

/**
 * Class that represents a mechanism to visualize text documents.
 * 
 * @author Michael Wurst, Ingo Mierswa
 * @version $Id: TextVisualizer.java,v 1.1 2007/05/27 21:45:37 ingomierswa Exp $
 */
public class TextVisualizer implements ObjectVisualizer {

    private static final long serialVersionUID = -7041933149816104684L;

    Map<String, WVTDocumentInfo> idMapping = null;

    WVTConfiguration wvtConfing = null;
    WVTool wvt = new WVTool(false);

    public TextVisualizer(WVTInputList list, WVTConfiguration wvtConfig, int idType) {
        idMapping = new HashMap<String, WVTDocumentInfo>();
        this.wvtConfing = wvtConfig;

        // Produce id mapping
        int counter = 1;
        Iterator e = list.getEntries();
        while (e.hasNext()) {
            WVTDocumentInfo docInfo = (WVTDocumentInfo) e.next();
            switch (idType) {
            case ExampleTableOutputFilter.ID_TYPE_LONG:
                idMapping.put(docInfo.getSourceName(), docInfo);
                break;
            case ExampleTableOutputFilter.ID_TYPE_SHORT:
                idMapping.put(docInfo.getSourceName().substring(
                        docInfo.getSourceName().lastIndexOf(java.io.File.separator) + 1), docInfo);
                break;
            case ExampleTableOutputFilter.ID_TYPE_NUMERICAL:
                idMapping.put((counter++) + "", docInfo);
                break;
            }
        }
    }

    public String getTitle(String objId) { return objId; }

    public boolean isCapableToVisualize(String id) {
        return idMapping.get(id) != null;
    }

    public void startVisualization(String objId) {
        WVTDocumentInfo docInfo = idMapping.get(objId);

        StringBuffer newText = new StringBuffer();

        try {
            BufferedReader in = new BufferedReader(wvt.getReader(docInfo, wvtConfing));
            String buf = null;
            while ((buf = in.readLine()) != null) {
                newText.append(buf + "\n");
            }
            in.close();
        } catch (Exception e) {
            LogService.getGlobal().log("Could not read text for id: " + e.getMessage(), LogService.ERROR);
        }
        
        JTextArea text = new JTextArea(20, 20);
        text.setLineWrap(true);
        text.setWrapStyleWord(true);
        text.setMargin(new Insets(10, 10, 10, 10));
        text.setText(newText.toString());
        text.setCaretPosition(0);
        
        JScrollPane scroll = new JScrollPane(text, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        JDialog dialog = new JDialog();
        dialog.setTitle("Text: " + getTitle(objId));
        dialog.getContentPane().add(scroll);
        dialog.pack();
        dialog.setLocationRelativeTo(null);
        
        dialog.setVisible(true);
    }

    public void stopVisualization(String objId) {}
}
