/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator.crawler;

import java.awt.Component;

import javax.swing.AbstractCellEditor;
import javax.swing.JComboBox;
import javax.swing.JTable;

import com.rapidminer.gui.properties.PropertyKeyCellEditor;
import com.rapidminer.operator.Operator;

/**
 * Parameter editor for the crawler properties.
 * 
 * @author Michael Wurst
 * @version $Id: CrawlerPolicyProperties.java,v 1.2 2007/06/04 12:52:14 ingomierswa Exp $
 */
public class CrawlerPolicyProperties extends AbstractCellEditor implements PropertyKeyCellEditor {

    private static final long serialVersionUID = -2559892872774108384L;

    private JComboBox predicateComboBox = null;

    public CrawlerPolicyProperties() {
        super();
    }

    public CrawlerPolicyProperties(ParameterTypeCrawlerPolicy type) {
        super();
        predicateComboBox = new JComboBox(new String[]{ "visit_url", "visit_content", "follow_url", "link_text" });
    }
   
    public boolean useEditorAsRenderer() {
        return true;
    }


    public void setOperator(Operator operator) {  
        // Does not need to be implemented
    }

    public Object getCellEditorValue() {
        String result = predicateComboBox.getSelectedItem().toString();
        return result;
    }
    
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int col) {
        return predicateComboBox;
    }

    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        return getTableCellEditorComponent(table, value, isSelected, row, column);
    }
}
