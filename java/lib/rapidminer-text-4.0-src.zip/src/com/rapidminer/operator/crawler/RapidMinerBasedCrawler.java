/*
 *  RapidMiner
 *
 *  Copyright (C) 2001-2007 by Rapid-I and the contributors
 *
 *  Complete list of developers available at our web site:
 *
 *       http://rapid-i.com
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License as 
 *  published by the Free Software Foundation; either version 2 of the
 *  License, or (at your option) any later version. 
 *
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 *  USA.
 */
package com.rapidminer.operator.crawler;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import websphinx.Crawler;
import websphinx.Link;
import websphinx.Page;

import com.rapidminer.example.Attribute;
import com.rapidminer.example.table.AttributeFactory;
import com.rapidminer.example.table.DataRow;
import com.rapidminer.example.table.DoubleArrayDataRow;
import com.rapidminer.tools.LoggingHandler;
import com.rapidminer.tools.Ontology;
import com.rapidminer.tools.math.matrix.ExtendedMatrix;
import com.rapidminer.tools.math.matrix.ExtendedSparseMatrix;

/**
 * A crawler class for the WVTool Plugin.
 * 
 * @author Michael Wurst, Ingo Mierswa
 * @version $Id: RapidMinerBasedCrawler.java,v 1.1 2007/05/27 21:45:37 ingomierswa Exp $
 *
 */
public class RapidMinerBasedCrawler extends Crawler {

	private static final long serialVersionUID = -614344545462107732L;

	private final File outputDir;

	private final int delay;

	private final Map<String, StringMatchingRuleSet> rules;

	private int currentId = 0;

//	private final DocumentSegmenter segmenter;

	private final List<DataRow> dataRows = new LinkedList<DataRow>();

	private final Attribute pathAttribute = AttributeFactory.createAttribute("document_source", Ontology.NOMINAL);

	private final Attribute urlAttribute = AttributeFactory.createAttribute("url", Ontology.NOMINAL);

	public static final String[] knownProperties = new String[] { "visit_url", "visit_content", "follow_url", "link_text" };

	private final ExtendedMatrix<String, String> linkMatrix = new ExtendedSparseMatrix<String, String>();

	private final Map<String, String> idURLMap = new HashMap<String, String>();

    private LoggingHandler logger;
    
	/**
	 * Initialize a crawler.
	 * @param rules the rules the crawler must obey. The map contains pairs of properties of a page or a link (see knownProperties) and rules sets for these properties.
	 * @param outputDir the directory to which to write the texts
	 * @param delayMillis the delay after visiting a page
	 * @param segmenter a document segmenter
	 */
	public RapidMinerBasedCrawler(Map<String, StringMatchingRuleSet> rules, File outputDir, int delayMillis, LoggingHandler logger) {
		super();
        this.outputDir = outputDir;
		this.delay = delayMillis;
		this.rules = rules;
//		this.segmenter = segmenter;
        this.logger = logger;

		// Set an empty rule set (which is always true) for all properties, for which no rules was provided
		for (int i = 0; i < knownProperties.length; i++)
			if (rules.get(knownProperties[i]) == null)
				this.rules.put(knownProperties[i], new StringMatchingRuleSet());
	}

	/** 
	 * Get all attributes for which feature values are added during the crawling process
	 * @return a list of attributes
	 */
	public List<Attribute> getCrawlerExtractedAttributes() {
		List<Attribute> result = new ArrayList<Attribute>();
		result.add(urlAttribute);
		result.add(pathAttribute);
		return result;
	}

	/**
	 * Get the data rows generated during the crawling process.
	 * @return a list of data rows
	 */
	public List<DataRow> getDataRows() {
		return dataRows;
	}

	private synchronized void writeLog(String s) {
		logger.log("Crawler : " + s);
	}

	private void addToExampleSet(String url, String fileName) {
		DataRow row = new DoubleArrayDataRow(new double[2]);
		row.set(urlAttribute, urlAttribute.getMapping().mapString(url));
		row.set(pathAttribute, pathAttribute.getMapping().mapString(fileName));
		dataRows.add(row);
	}

	private synchronized void store(Page p) {
			BufferedWriter out = null;

            String fileName = outputDir.getAbsolutePath() + File.separator + currentId + ".txt";
            try {
				addToExampleSet(p.getURL().toExternalForm(), fileName);
				out = new BufferedWriter(new FileWriter(fileName));
				out.write(p.getContent());
				out.close();
			} catch (IOException e) {
				logger.logError("Could not store file " + fileName);
			}
	
		addLinks(p, currentId);
		currentId++;
	}

	private void addLinks(Page p, int id) {
		String source = p.getURL().toExternalForm();
		Link[] links = p.getLinks();
		for (int i = 0; i < links.length; i++) {
			String target = links[i].getURL().toExternalForm();
			linkMatrix.setEntry(source, target, 1.0);
		}
		idURLMap.put(source, id + "");
	}

	public LinkMatrix getLinkMatrix() {
 		LinkMatrix result = new LinkMatrix();
		for (Iterator<String> it = linkMatrix.getXLabels(); it.hasNext();) {
			String xLabel = it.next();
			for (Iterator<String> it2 = linkMatrix.getYEntries(xLabel); it2.hasNext();) {
				String yLabel = it2.next();
				String xId = xLabel;
				String yId = yLabel;
				if ((xId != null) && (yId != null))
                    if((idURLMap.get(xLabel) != null)&&(idURLMap.get(yLabel) != null))
                        if (linkMatrix.getEntry(xLabel, yLabel) > 0.0)
                            result.setLink(xId, yId);
			}
		}
		return result;
	}

	public boolean shouldVisit(Link link) {
		// Check against the rules
		String targetURL = link.getURL().toExternalForm();
		String linkText = link.toText();

		StringMatchingRuleSet urlRules = rules.get("follow_url");
		StringMatchingRuleSet textRules = rules.get("link_text");

		if (urlRules.check(targetURL) && textRules.check(linkText)) {
			writeLog("Following link to " + targetURL);
			return true;
		} else {
			writeLog("Not following link to " + targetURL);
			return false;
		}
	}

	public void visit(Page p) {
		// Delay the execution
		try {
			if (delay > 0)
				Thread.sleep(delay);
		} catch (InterruptedException e) {
			// Do not do anything
		}

		// Check against the rules
		if (rules.get("visit_url").check(p.getURL().toExternalForm()) && rules.get("visit_content").check(p.getContent())) {
			writeLog("Storing page " + p.getURL().toExternalForm());
			// Write page
			store(p);
		} else {
			writeLog("Did not store page " + p.getURL().toExternalForm());
		}
		p.discardContent();
	}
}
